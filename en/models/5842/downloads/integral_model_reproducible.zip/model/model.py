"""Integral: dated fee bases, explicit costs, conditional exits and funded cash.

JPY millions, shares millions, EPS yen. Guidance is never imported.
Recurring EPS means fee-only parent earnings. Total EPS is a separate
conditional investment/carry scenario, not interchangeable with recurring EPS.
"""
import copy


def evaluate(inputs, case='base'):
    a=inputs['actual'];p=inputs['cases'][case];c=inputs['conventions']
    cash=a['cash'];debt=a['debt'];fee_base=a['fee_earning_aum']
    fixed=(a['recurring_cost']-a['da']-p['variable_fee_cost']*(a['management_fees']+a['support_fees']))/a['actual_fraction']
    assets=a['investments'];carry_stock=a['unrealized_carry'];equity=a['parent_equity']
    deferred_tax=a['deferred_tax_liability']
    receivables=a['receivables'];advances=a['advances'];previous_new=0;rows=[]
    for i,year in enumerate(c['years']):
        duration=c['first_fraction'] if i==0 else 1
        actual=i==0
        new=p['new_fund_commitments'][i]*(1-p['gp_fraction'])
        ending_fee_base=p['existing_fee_base_end'][i]
        fees=((fee_base+ending_fee_base)/2+(previous_new+new)/2)*p['fee_rate']*duration
        support=a['support_fees']/a['actual_fraction']*(1+p['support_growth'])**i*duration
        revenue=fees+support;variable=revenue*p['variable_fee_cost']
        fixed*= (1+p['fixed_cost_growth'])**duration
        capex=p['annual_capex']*duration
        da=(a['da']/a['actual_fraction']+p['annual_capex']/p['asset_life']*(i+duration/2))*duration
        fee_op=revenue-variable-fixed*duration-da
        carry=p['carry_realizations'][i]
        if carry<0 or carry>carry_stock:raise ValueError('Carry exceeds disclosed available pool')
        carry_stock-=carry
        investment_mark=assets*p['investment_mark_return']*duration
        dividends=a['investment_dividends']/a['actual_fraction']*duration
        total_op=fee_op+carry*(1-p['carry_bonus'])+investment_mark+dividends
        repay=min(debt,p['opening_debt_repaid']*duration/c['first_fraction']) if actual else 0
        interest=(debt-repay/2)*p['debt_rate']*duration+p['lease_interest']*duration
        cash_interest=cash*p['cash_yield']*duration
        nci=a['nci']/a['actual_fraction']*(1+p['nci_growth'])**i*duration
        new_commitment=max(0,p['new_fund_commitments'][i]-(p['new_fund_commitments'][i-1] if i else 0))
        successor_call=new_commitment*p['gp_fraction']*p['first_year_gp_call']
        # Latest actual investment-book increase less identified noncash marks
        # anchors NET investment cash deployment. No invented gross calls/exits.
        net_deployment=p['annual_net_investment_deployment']*duration+successor_call
        end_ar=revenue/duration*p['fee_receivable_days']/c['days']+carry*p['carry_receivable_fraction']
        end_advances=fees/duration*p['advance_months']/c['months']
        wc=end_ar-receivables-(end_advances-advances)
        parent_dividend=0 if actual else max(0,equity)*p['dividend_doe']
        tax_payable=a['tax_payable'] if actual else 0
        opening_bonus=a['bonus_provision'] if i==p['opening_bonus_settlement_period'] else 0
        draw=0
        for _ in range(c['funding_iterations']):
            funding_interest=draw*p['debt_rate']*duration/2
            pbt=total_op+cash_interest-interest-funding_interest
            tax=max(0,pbt)*p['tax_rate']
            parent=pbt-tax-nci
            # FV marks are not cash; only the non-mark taxable income funds tax.
            cash_tax=max(0,pbt-investment_mark)*p['tax_rate']
            cfo=parent+nci+da-investment_mark+(tax-cash_tax)-wc-tax_payable-opening_bonus
            before=cash+cfo-capex-net_deployment-parent_dividend-p['lease_principal']*duration-repay
            required=max(0,p['minimum_cash']-before)
            if abs(required-draw)<c['funding_tolerance']:break
            draw=required
        ending_cash=before+draw
        deferred_tax=max(0,deferred_tax+tax-cash_tax)
        fee_parent=(fee_op-interest-funding_interest)*(1-p['tax_rate'])-nci
        known_fees=a['management_fees']+a['support_fees'] if actual else 0
        known_fee_op=known_fees-a['recurring_cost'] if actual else 0
        known_fee_parent=((known_fee_op-a['finance_cost'])*(1-p['tax_rate'])-a['nci']) if actual else 0
        shares=(a['weighted_shares']*a['actual_fraction']+a['closing_shares']*duration) if actual else a['closing_shares']
        full_revenue=revenue+known_fees
        full_variable=variable+known_fees*p['variable_fee_cost']
        full_sga=fixed*duration+da+(a['recurring_cost']-known_fees*p['variable_fee_cost'] if actual else 0)
        full_op=fee_op+known_fee_op;full_parent=fee_parent+known_fee_parent
        full_total_parent=parent+(a['parent_profit'] if actual else 0)
        row=dict(period_end=f'{year}-12-31',revenue=full_revenue,gross_profit=full_revenue-full_variable,sga=full_sga,
                 ebit=full_op,op_margin=full_op/full_revenue,recurring_parent_profit=full_parent,shares_m=shares,
                 recurring_eps=full_parent/shares,cash=ending_cash,debt=debt-repay+draw,
                 total_parent_profit=full_total_parent,total_eps=full_total_parent/shares,
                 realized_carry=carry+(a['realized_carry'] if actual else 0),
                 cash_after_deferred_tax_reserve=ending_cash-deferred_tax,deferred_tax_reserve=deferred_tax,
                 forward_period_fraction=duration,forward_fee_revenue=revenue,forward_variable_cost=variable,
                 management_fees=fees+(a['management_fees'] if actual else 0),support_fees=support+(a['support_fees'] if actual else 0),
                 variable_cost=full_variable,fixed_cost=full_sga-da-(a['da'] if actual else 0),da=da+(a['da'] if actual else 0),
                 forward_fixed_cost=fixed*duration,forward_da=da,forward_net_investment_cash_use=net_deployment,
                 forward_cfo=cfo,forward_capex=capex,dividend_cash=parent_dividend,principal=repay,draw=draw,
                 funding_interest=funding_interest,forward_cash_tax=cash_tax,forward_tax=tax,forward_nci=nci,
                 opening_bonus_settlement=opening_bonus,debt_basis='Borrowings excluding lease liabilities',
                 forward_interest=interest,forward_cash_interest=cash_interest,
                 closing_fee_earning_aum=ending_fee_base+new,remaining_carry_pool=carry_stock,
                 equity=equity+parent-parent_dividend,forecast_period='Q4 only' if actual else 'full year')
        assert abs(row['gross_profit']-row['sga']-row['ebit'])<1e-7
        rows.append(row);cash=ending_cash;debt=row['debt'];equity=row['equity']
        assets+=net_deployment+investment_mark;fee_base=ending_fee_base;previous_new=new
        receivables=end_ar;advances=end_advances
    return dict(annual=rows,eps_cagr=(rows[-1]['recurring_eps']/rows[0]['recurring_eps'])**(1/3)-1 if rows[0]['recurring_eps']>0 and rows[-1]['recurring_eps']>0 else None,
                total_eps_cagr=(rows[-1]['total_eps']/rows[0]['total_eps'])**(1/3)-1 if rows[0]['total_eps']>0 and rows[-1]['total_eps']>0 else None)
