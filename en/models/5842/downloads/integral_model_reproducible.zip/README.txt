Run python model/model.py to reproduce all cases.
Validate: from tools.forecast_evidence import validate_run; validate_run("model/ECONOMIC_CONTRACT.json", replay=True).
Units: JPY millions, million shares, EPS yen. Follow explicit field names for input/output share units. Guidance is not an input.
