"""Reviewer-owned Integral reconstruction; never authors production inputs."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[1]


def own_forecast(x,case='base'):
    a=x['actual'];p=x['cases'][case];c=x['conventions']
    cash,debt,equity=a['cash'],a['debt'],a['parent_equity']
    fixed_rate=(a['recurring_cost']-a['da']-p['variable_fee_cost']*(a['management_fees']+a['support_fees']))/a['actual_fraction']
    prior_fee=a['fee_earning_aum'];prior_new=0.;investments=a['investments'];stock=a['unrealized_carry']
    receivables,advances=a['receivables'],a['advances'];dt=a['deferred_tax_liability'];rows=[]
    for year_index,year in enumerate(c['years']):
        fraction=c['first_fraction'] if year_index==0 else 1.
        existing=p['existing_fee_base_end'][year_index]
        committed=p['new_fund_commitments'][year_index]
        new_external=committed*(1-p['gp_fraction'])
        fee=p['fee_rate']*((prior_fee+existing+prior_new+new_external)/2)*fraction
        service=a['support_fees']/a['actual_fraction']*(1+p['support_growth'])**year_index*fraction
        sales=fee+service
        fixed_rate*=(1+p['fixed_cost_growth'])**fraction
        depreciation=(a['da']/a['actual_fraction']+p['annual_capex']/p['asset_life']*(year_index+fraction/2))*fraction
        op=sales*(1-p['variable_fee_cost'])-fixed_rate*fraction-depreciation
        carry=p['carry_realizations'][year_index];stock-=carry
        mark=investments*p['investment_mark_return']*fraction
        investment_distribution=a['investment_dividends']/a['actual_fraction']*fraction
        total_op=op+carry*(1-p['carry_bonus'])+mark+investment_distribution
        repayment=min(debt,p['opening_debt_repaid']) if year_index==0 else 0.
        base_interest=(debt-repayment/2)*p['debt_rate']*fraction+p['lease_interest']*fraction
        cash_interest=cash*p['cash_yield']*fraction
        outsider=a['nci']/a['actual_fraction']*(1+p['nci_growth'])**year_index*fraction
        first_call=max(0.,committed-(p['new_fund_commitments'][year_index-1] if year_index else 0.))*p['gp_fraction']*p['first_year_gp_call']
        deployment=p['annual_net_investment_deployment']*fraction+first_call
        next_ar=sales/fraction*p['fee_receivable_days']/365+carry*p['carry_receivable_fraction']
        next_advance=fee/fraction*p['advance_months']/12
        wc=(next_ar-receivables)-(next_advance-advances)
        payout=max(0.,equity)*p['dividend_doe'] if year_index else 0.
        due_tax=a['tax_payable'] if year_index==0 else 0.
        accrued_bonus=a['bonus_provision'] if year_index==p['opening_bonus_settlement_period'] else 0.
        capex=p['annual_capex']*fraction
        def settle(borrowing):
            extra_interest=borrowing*p['debt_rate']*fraction/2
            pretax=total_op+cash_interest-base_interest-extra_interest
            booktax=max(0.,pretax)*p['tax_rate']
            cashtax=max(0.,pretax-mark)*p['tax_rate']
            parent=pretax-booktax-outsider
            cfo=pretax-cashtax+depreciation-mark-wc-due_tax-accrued_bonus
            final_cash=cash+cfo-capex-deployment-payout-p['lease_principal']*fraction-repayment+borrowing
            return final_cash,parent,cfo,booktax,cashtax,extra_interest
        low=0.;high=max(1.,p['minimum_cash']-settle(0.)[0])
        if settle(0.)[0]>=p['minimum_cash']:
            borrowing=0.
        else:
            while settle(high)[0]<p['minimum_cash']:high*=2
            for _ in range(100):
                mid=(low+high)/2
                if settle(mid)[0]<p['minimum_cash']:low=mid
                else:high=mid
            borrowing=high
        end_cash,parent,cfo,tax,cash_tax,extra_interest=settle(borrowing)
        shares=(a['weighted_shares']*a['actual_fraction']+a['closing_shares']*fraction) if year_index==0 else a['closing_shares']
        known_fee=a['management_fees']+a['support_fees'] if year_index==0 else 0.
        known_op=known_fee-a['recurring_cost'] if year_index==0 else 0.
        known_fee_parent=(known_op-a['finance_cost'])*(1-p['tax_rate'])-a['nci'] if year_index==0 else 0.
        fee_parent=(op-base_interest-extra_interest)*(1-p['tax_rate'])-outsider+known_fee_parent
        total_parent=parent+(a['parent_profit'] if year_index==0 else 0.)
        dt=max(0.,dt+tax-cash_tax)
        debt=debt-repayment+borrowing;equity+=parent-payout
        rows.append(dict(period_end=f'{year}-12-31',revenue=sales+known_fee,ebit=op+known_op,recurring_eps=fee_parent/shares,total_eps=total_parent/shares,cash=end_cash,debt=debt,draw=borrowing,forward_cfo=cfo,forward_net_investment_cash_use=deployment,deferred_tax_reserve=dt,cash_after_deferred_tax_reserve=end_cash-dt))
        cash=end_cash;investments+=deployment+mark;prior_fee=existing;prior_new=new_external
        receivables,advances=next_ar,next_advance
    return rows


def main():
    inputs=json.loads((R/'model/INPUTS.json').read_text('utf8'))
    spec=importlib.util.spec_from_file_location('submitted_integral',R/'model/model.py')
    submitted=importlib.util.module_from_spec(spec);spec.loader.exec_module(submitted)
    comparisons={};errors=[]
    for case in inputs['cases']:
        own=own_forecast(inputs,case);candidate=submitted.evaluate(copy.deepcopy(inputs),case)['annual']
        for left,right in zip(own,candidate):
            for key in left:
                if key=='period_end':continue
                if abs(left[key]-right[key])>1e-7:errors.append([case,left['period_end'],key,left[key],right[key]])
        comparisons[case]=own
    variations={
        'fee_rate_2pct':{'fee_rate':.02},
        'no_successor':{'new_fund_commitments':[0,0,0,0]},
        'half_net_deployment':{'annual_net_investment_deployment':3250.},
        'one_and_half_net_deployment':{'annual_net_investment_deployment':9750.},
        'no_future_carry':{'carry_realizations':[0,0,0,0]},
        'debt_rollover':{'opening_debt_repaid':0.},
        'bonus_in_q4':{'opening_bonus_settlement_period':0}
    }
    sensitivities={}
    for name,override in variations.items():
        amended=copy.deepcopy(inputs);amended['cases']['base'].update(override)
        sensitivities[name]=own_forecast(amended)
    source_calcs={'annual_net_deployment_m':(65874-57711-1378-1910)/.75,'q3_management_fees_m':5682-3860,'q3_effective_fee_rate_on_average_fee_aum':(5682-3860)*4/((366100+359200)/2),'fee_aum_excludes_gp':'Issuer resultsENp9 explicitly excludes the2%GP capital from Fee-EarningAUM.'}
    sealed_sensitivities=json.loads((R/'model/SENSITIVITIES.json').read_text('utf8'))['sensitivities']
    for sensitivity in sealed_sensitivities:
        amended=copy.deepcopy(inputs)
        for path,value in sensitivity['input_changes'].items():
            node=amended;parts=path.strip('/').split('/')
            for part in parts[:-1]:node=node[part]
            node[parts[-1]]=value
        own=own_forecast(amended)
        target={'fy0_eps':own[0]['recurring_eps'],'fy3_eps':own[-1]['recurring_eps'],'target_cash':own[-1]['cash'],'target_debt':own[-1]['debt']}
        for key,value in target.items():
            if abs(value-sensitivity[key])>1e-7:errors.append(['sensitivity',sensitivity['label'],key,value,sensitivity[key]])
    result={'stage':'FINAL_INDEPENDENT_RECONSTRUCTION','hashes':{n:hashlib.sha256((R/'model'/n).read_bytes()).hexdigest() for n in ['model.py','INPUTS.json','DRIVER_NOTES.json']},'errors':errors,'source_calculations':source_calcs,'comparisons':comparisons,'sensitivities':sensitivities,'sealed_sensitivities_checked':len(sealed_sensitivities)}
    (R/'reviews/INDEPENDENT_RECONSTRUCTION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'errors':errors,'source_calculations':source_calcs,'base':comparisons['base'],'sensitivity_targets':{n:r[-1] for n,r in sensitivities.items()}},indent=2))


if __name__=='__main__':main()
