"""Reviewer-owned independent f-code calculation; not production authoring."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[1]


def own_forecast(x,case='base'):
    a=x['actual'];p=x['cases'][case];c=x['conventions']
    fraction=c['quarter'];annual_sales=a['q3_revenue']/fraction
    cash_cost=(a['q3_revenue']-a['q3_gp_less_sga']-a['q3_da'])/fraction
    variable,fixed=cash_cost*p['variable_cash_share'],cash_cost*(1-p['variable_cash_share'])
    direct_share=a['q3_cogs']/(variable*fraction)
    cash,debt,shares=a['cash'],a['bank_bond_debt'],a['closing_shares']
    receivables,payables,advances=a['receivables'],a['payables'],a['customer_advances']
    outside=a['q3_nci']/fraction;initial_outside=outside
    put_stock=a['other_financial_liabilities']*p['seller_pool_multiplier']*p['put_mix']
    earn_stock=a['other_financial_liabilities']*p['seller_pool_multiplier']*(1-p['put_mix'])
    credit_anchor=max(1.,(a['q3_revenue']-a['customer_advances']*c['reference_advance_delivery'][0])/fraction)
    normalized_op=a['ytd_reported_op']-a['h1_other_income_adjustment']+a['h1_impairment_adjustment']
    normalized_parent=a['ytd_parent_profit']-a['h1_other_income_adjustment']*(1-p['valuation_income_tax_rate'])+a['h1_impairment_adjustment']*(1-p['impairment_tax_benefit_rate'])
    put_done=earn_done=0.;elapsed=0.;tax_deferral=0.;capital=[];rows=[]
    for i,year in enumerate(c['years']):
        duration=fraction if i==0 else 1.
        real=1+p['activity_growth'][i];price=(1+p['price_mix'])**duration
        nominal=annual_sales*real*price*duration
        recognized=min(advances,a['customer_advances']*p['advance_delivery'][i])
        reference=a['customer_advances']*c['reference_advance_delivery'][i]
        refund=min(max(0.,advances-recognized),a['customer_advances']*p['advance_refund'][i])
        timing=recognized-reference
        sales=nominal+timing;advances-=recognized+refund
        cash_variable=variable*real*(1+p['variable_input_inflation'])**duration*duration+timing*variable/annual_sales
        cash_fixed=fixed*(1+p['fixed_cost_growth'])**duration*duration
        capex=p['maintenance_capex']*duration+max(0.,nominal/duration-annual_sales)*p['growth_capex_rate']*duration
        capital.append(capex)
        depreciation=a['q3_da']/fraction*duration+sum(v/p['asset_life']*duration*(.5 if j==i else 1.) for j,v in enumerate(capital))
        other=a['q3_unclassified_other_profit']/fraction*duration*p['future_other_profit_repeat']
        op=sales-cash_variable-cash_fixed-depreciation+other
        outside*=(1+p['outside_claim_growth'])**duration
        # The submitted final convention must use elapsed time from September,
        # including its initial quarter, rather than a full-year index.
        at_point=(outside/initial_outside)**p['seller_performance_elasticity']*(1+p['seller_time_value'])**(elapsed+duration/2)
        put_point,earn_point=put_stock*at_point,earn_stock*at_point
        put_fraction,earn_fraction=p['put_exercise'][i],p['earnout_payment'][i]
        put_cash,earn_cash=put_point*put_fraction,earn_point*earn_fraction
        minority=outside*(1-p['put_covered_outside_claim']*(put_done+put_fraction/2))*duration
        unwind_base=put_stock*(1-put_done-put_fraction/2)+earn_stock*(1-earn_done-earn_fraction/2)
        unwind=unwind_base*(1+p['seller_time_value'])**elapsed*((1+p['seller_time_value'])**duration-1)
        put_done+=put_fraction;earn_done+=earn_fraction
        remaining_put,remaining_earn=put_point*(1-put_done),earn_point*(1-earn_done)
        fixed_price=p['fixed_ai_one_payments'][i]
        credit_sales=max(0.,sales-recognized)
        next_ar=a['receivables']*(credit_sales/duration)/credit_anchor
        next_ap=a['payables']*(sales/duration)/(a['q3_revenue']/fraction)
        wc=next_ar-receivables-(next_ap-payables)
        principal=min(debt,p['bank_principal'][i]);lease_principal=p['annual_lease_principal']*duration
        if i<len(c['years'])-1:
            next_duration=1.
            next_performance=(outside*(1+p['outside_claim_growth'])**next_duration/initial_outside)**p['seller_performance_elasticity']
            next_time=(1+p['seller_time_value'])**(elapsed+duration+next_duration/2)
            scheduled=(put_stock*p['put_exercise'][i+1]+earn_stock*p['earnout_payment'][i+1])*next_performance*next_time
            next_fixed=p['fixed_ai_one_payments'][i+1]
        else:scheduled=next_fixed=0.
        reserve=scheduled+next_fixed+p['reserve_all_remaining_fraction']*max(0.,remaining_put+remaining_earn-scheduled)+advances*p['customer_fulfillment_cost_fraction']
        floor=sales/duration/c['months']*p['cash_floor_months'];target=floor+reserve
        max_credit=max(0.,a['bank_bond_debt']*p['funding_debt_ceiling_multiple']-(debt-principal))*p['refinance_fraction']
        def settle(credit):
            interest=(debt-principal/2+credit/2)*p['bank_rate']*duration+a['lease_debt']*p['lease_rate']*duration
            cash_income=cash*p['cash_yield']*duration
            pretax=op+cash_income-interest-unwind
            tax=max(0.,pretax)*p['tax_rate'];parent=pretax-tax-minority
            cash_tax=max(0.,pretax-other)*p['tax_rate']
            cfo=op+depreciation-other+cash_income-interest-cash_tax-wc-recognized-refund
            before=cash+cfo-capex-lease_principal-put_cash-earn_cash-fixed_price-principal-(a['tax_payable'] if i==0 else 0.)
            return before+credit,parent,cfo,tax,interest,cash_tax
        if settle(0.)[0]>=target:credit=0.
        elif settle(max_credit)[0]<target:credit=max_credit
        else:
            lo,hi=0.,max_credit
            for _ in range(100):
                mid=(lo+hi)/2
                if settle(mid)[0]<target:lo=mid
                else:hi=mid
            credit=hi
        end_cash,parent,cfo,tax,interest,cash_tax=settle(credit)
        equity=max(0.,target-end_cash);issued=equity/(p['equity_reference_price']*(1-p['equity_issue_discount']))
        weighted=(a['ytd_weighted_shares']*a['actual_fraction']+shares*duration if i==0 else shares)+issued*duration/2
        full_sales=sales+(a['ytd_revenue'] if i==0 else 0.)
        full_parent=parent+(normalized_parent if i==0 else 0.)
        full_op=op+(normalized_op if i==0 else 0.)
        gp=sales-cash_variable*direct_share+(a['ytd_gp'] if i==0 else 0.)
        sga=cash_variable*(1-direct_share)+cash_fixed+depreciation+(a['ytd_sga'] if i==0 else 0.)
        other_operating=other+(normalized_op-(a['ytd_gp']-a['ytd_sga']) if i==0 else 0.)
        cash=end_cash+equity;debt=debt-principal+credit;shares+=issued
        tax_deferral+=tax-cash_tax
        row=dict(period_end=f'{year}-12-31',revenue=full_sales,gross_profit=gp,sga=sga,other_operating_profit=other_operating,ebit=full_op,recurring_parent_profit=full_parent,recurring_eps=full_parent/weighted,shares_m=weighted,cash=cash,debt=debt,forward_nci=minority,forward_tax=tax,forward_cash_tax=cash_tax,incremental_future_other_tax_deferral=tax_deferral,forward_interest=interest,put_cash=put_cash,earnout_cash=earn_cash,fixed_price_cash=fixed_price,remaining_put_cashpoint=remaining_put,remaining_earnout_cashpoint=remaining_earn,closing_customer_advances=advances,liquidity_reserve=reserve,cash_floor=floor,draw=credit,equity_cash=equity,new_shares_m=issued,forward_cfo=cfo,forward_capex=capex)
        rows.append(row);receivables,payables=next_ar,next_ap
        annual_sales=nominal/duration;variable*=real*(1+p['variable_input_inflation'])**duration;fixed*=(1+p['fixed_cost_growth'])**duration
        elapsed+=duration
    return rows


def main():
    x=json.loads((R/'model/INPUTS.json').read_text('utf8'))
    spec=importlib.util.spec_from_file_location('submitted_fcode',R/'model/model.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    errors=[];cases={}
    def compare(name,amended,case='base'):
        own=own_forecast(amended,case);submitted=m.evaluate(copy.deepcopy(amended),case)['annual']
        for left,right in zip(own,submitted):
            for key in left:
                if key!='period_end' and abs(left[key]-right[key])>1e-7:errors.append([name,left['period_end'],key,left[key],right[key]])
        return own
    for case in x['cases']:cases[case]=compare(case,x,case)
    sealed_path=R/'model/SENSITIVITIES.json';sensitivities={}
    if sealed_path.exists():
        for sensitivity in json.loads(sealed_path.read_text('utf8'))['sensitivities']:
            amended=copy.deepcopy(x)
            for path,value in sensitivity['input_changes'].items():
                node=amended;parts=path.strip('/').split('/')
                for part in parts[:-1]:node=node[part]
                node[parts[-1]]=value
            own=compare(sensitivity['label'],amended);sensitivities[sensitivity['label']]=own
            for key,value in {'fy0_eps':own[0]['recurring_eps'],'fy3_eps':own[-1]['recurring_eps'],'target_cash':own[-1]['cash'],'target_debt':own[-1]['debt']}.items():
                if abs(value-sensitivity[key])>1e-7:errors.append(['sealed_sensitivity',sensitivity['label'],key,value,sensitivity[key]])
    h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    extra={}
    changes={
        'all_seller_and_fixed_cash_immediate':{'put_exercise':[1,0,0,0],'earnout_payment':[1,0,0,0],'fixed_ai_one_payments':[750,0,0,0]},
        'no_new_credit_available':{'refinance_fraction':0},
        'declining_activity_loss_case':{'activity_growth':[-.05,-.1,-.1,-.1],'price_mix':0},
        'no_effective_price_mix':{'price_mix':0},
        'tighter_credit_75pct_original_issue_price':{'funding_debt_ceiling_multiple':.75},
        'repeat_unknown_non_cash_loss':{'future_other_profit_repeat':-1},
        'variable_share_80pct':{'variable_cash_share':.8},
        'zero_seller_performance_elasticity':{'seller_performance_elasticity':0}}
    for name,overrides in changes.items():
        amended=copy.deepcopy(x);amended['cases']['base'].update(overrides)
        extra[name]=compare(name,amended)
    for i,bridge in enumerate(json.loads((R/'model/BRIDGES.json').read_text('utf8'))['annual_changes']):
        for key in ['ebit','recurring_eps']:
            error=sum(item['change'] for item in bridge[key])-(cases['base'][i+1][key]-cases['base'][i][key])
            if abs(error)>1e-7:errors.append(['bridge',bridge['to'],key,error])
    result=dict(stage='FINAL_INDEPENDENT_RECONSTRUCTION',errors=errors,hashes={n:h(R/'model'/n) for n in ['model.py','INPUTS.json','DRIVER_NOTES.json']},comparisons=cases,sensitivities=sensitivities,extra_review_sensitivities=extra,annual_bridge_check='PASS' if not errors else 'FAIL')
    (R/'reviews/INDEPENDENT_RECONSTRUCTION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'errors':errors[:20],'base':cases['base'],'sealed_sensitivities_checked':len(sensitivities)},indent=2))


if __name__=='__main__':main()
