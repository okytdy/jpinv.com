"""f-code: latest service cost budget, conditional seller claims and financing.

JPY millions/million shares, EPS yen. The current business scope is already
consolidated in Q3. No new M&A, guidance import or assumed valuation windfall.
"""

def evaluate(inputs,case='base'):
    a=inputs['actual'];p=inputs['cases'][case];c=inputs['conventions']
    annual_sales=a['q3_revenue']/c['quarter']
    annual_cash_cost=(a['q3_revenue']-a['q3_gp_less_sga']-a['q3_da'])/c['quarter']
    variable=annual_cash_cost*p['variable_cash_share'];fixed=annual_cash_cost-variable
    direct_share=a['q3_cogs']/(annual_cash_cost*c['quarter']*p['variable_cash_share'])
    if not 0<direct_share<=1:raise ValueError('Variable pool cannot contain the observed direct costs')
    variable_sga_fraction=(annual_cash_cost*c['quarter']*p['variable_cash_share']-a['q3_cogs'])/(annual_cash_cost*c['quarter']-a['q3_cogs'])
    cash=a['cash'];debt=a['bank_bond_debt'];shares=a['closing_shares']
    ar=a['receivables'];ap=a['payables'];contract=a['customer_advances']
    put_paid=earn_paid=0;elapsed=0;other_tax_deferral=0;rows=[];asset_cohorts=[]
    nci_annual=a['q3_nci']/c['quarter'];initial_nci=nci_annual
    seller_pool=a['other_financial_liabilities']*p['seller_pool_multiplier']
    credit_anchor=max(1,(a['q3_revenue']-a['customer_advances']*c['reference_advance_delivery'][0])/c['quarter'])
    opening_put=seller_pool*p['put_mix'];opening_earn=seller_pool-opening_put
    identified=a['h1_other_income_adjustment']-a['h1_impairment_adjustment']
    known_op=a['ytd_reported_op']-identified
    known_parent=a['ytd_parent_profit']-a['h1_other_income_adjustment']*(1-p['valuation_income_tax_rate'])+a['h1_impairment_adjustment']*(1-p['impairment_tax_benefit_rate'])
    for i,year in enumerate(c['years']):
        actual=i==0;duration=c['quarter'] if actual else 1
        activity=1+p['activity_growth'][i]
        price=(1+p['price_mix'])**duration
        nominal_revenue=annual_sales*activity*price*duration
        earned=min(contract,a['customer_advances']*p['advance_delivery'][i])
        reference_earned=a['customer_advances']*c['reference_advance_delivery'][i]
        refund=min(max(0,contract-earned),a['customer_advances']*p['advance_refund'][i])
        timing_delta=earned-reference_earned
        revenue=nominal_revenue+timing_delta
        contract-=earned+refund
        volume=activity
        variable_period=variable*volume*(1+p['variable_input_inflation'])**duration*duration
        variable_period+=timing_delta*variable/annual_sales
        fixed_period=fixed*(1+p['fixed_cost_growth'])**duration*duration
        capex=p['maintenance_capex']*duration+max(0,nominal_revenue/duration-annual_sales)*p['growth_capex_rate']*duration
        asset_cohorts.append((i,capex))
        # Existing total D&A is held at the observed quarter run-rate. New cash
        # capex is depreciated separately; no unexplained legacy asset write-off.
        da=a['q3_da']/c['quarter']*duration+sum(spend/p['asset_life']*(duration/2 if start==i else duration) for start,spend in asset_cohorts)
        other_profit=a['q3_unclassified_other_profit']/c['quarter']*duration*p['future_other_profit_repeat']
        op=revenue-variable_period-fixed_period-da+other_profit
        nci_annual*= (1+p['outside_claim_growth'])**duration
        performance=nci_annual/initial_nci
        midpoint=elapsed+duration/2
        put_point=opening_put*performance**p['seller_performance_elasticity']*(1+p['seller_time_value'])**midpoint
        earn_point=opening_earn*performance**p['seller_performance_elasticity']*(1+p['seller_time_value'])**midpoint
        put_fraction=p['put_exercise'][i];earn_fraction=p['earnout_payment'][i]
        if put_paid+put_fraction>1+1e-10 or earn_paid+earn_fraction>1+1e-10:raise ValueError('Duplicate seller-pool settlement')
        put_cash=put_point*put_fraction;earn_cash=earn_point*earn_fraction
        average_bought=put_paid+put_fraction/2
        nci=nci_annual*(1-p['put_covered_outside_claim']*average_bought)*duration
        unwind_base=(opening_put*(1-put_paid-put_fraction/2)+opening_earn*(1-earn_paid-earn_fraction/2))
        unwind=unwind_base*(1+p['seller_time_value'])**elapsed*((1+p['seller_time_value'])**duration-1)
        put_paid+=put_fraction;earn_paid+=earn_fraction
        pending_put=put_point*(1-put_paid);pending_earn=earn_point*(1-earn_paid)
        fixed_price=p['fixed_ai_one_payments'][i]
        # Fixed deferred price purchases an already-owned75% stake: cash only,
        # with no incremental minority-earnings or ownership benefit.
        credit_revenue=max(0,revenue-earned)
        end_ar=a['receivables']*(credit_revenue/duration)/credit_anchor
        end_ap=a['payables']*(revenue/duration)/(a['q3_revenue']/c['quarter'])
        wc=end_ar-ar-(end_ap-ap)
        repayment=min(debt,p['bank_principal'][i])
        lease_principal=p['annual_lease_principal']*duration
        next_put=p['put_exercise'][i+1] if i<3 else 0
        next_earn=p['earnout_payment'][i+1] if i<3 else 0
        next_fixed=p['fixed_ai_one_payments'][i+1] if i<3 else 0
        next_performance=performance*(1+p['outside_claim_growth']) if i<3 else performance
        next_midpoint=elapsed+duration+.5
        next_put_point=opening_put*next_performance**p['seller_performance_elasticity']*(1+p['seller_time_value'])**next_midpoint
        next_earn_point=opening_earn*next_performance**p['seller_performance_elasticity']*(1+p['seller_time_value'])**next_midpoint
        scheduled_reserve=next_put_point*next_put+next_earn_point*next_earn
        seller_reserve=scheduled_reserve+next_fixed+p['reserve_all_remaining_fraction']*max(0,pending_put+pending_earn-scheduled_reserve)
        fulfillment_reserve=contract*p['customer_fulfillment_cost_fraction']
        cash_floor=revenue/duration/c['months']*p['cash_floor_months']
        reserve=seller_reserve+fulfillment_reserve
        refinance=equity=0
        for _ in range(c['funding_iterations']):
            bank_interest=(debt-repayment/2+refinance/2)*p['bank_rate']*duration
            lease_interest=a['lease_debt']*p['lease_rate']*duration
            cash_interest=cash*p['cash_yield']*duration
            pbt=op+cash_interest-bank_interest-lease_interest-unwind
            tax=max(0,pbt)*p['tax_rate']
            cash_tax=max(0,pbt-other_profit)*p['tax_rate']
            parent=pbt-tax-nci
            # The unclassified-other-profit repeat sensitivity is noncash;
            # neither the gain nor its associated deferred tax funds payments.
            cfo=op+da-other_profit+cash_interest-bank_interest-lease_interest-cash_tax-wc-earned-refund
            before=cash+cfo-capex-lease_principal-put_cash-earn_cash-fixed_price-repayment-(a['tax_payable'] if actual else 0)
            need=max(0,cash_floor+reserve-before)
            available_credit=max(0,a['bank_bond_debt']*p['funding_debt_ceiling_multiple']-(debt-repayment))
            new_refinance=min(need,available_credit*p['refinance_fraction'])
            new_equity=max(0,need-new_refinance)
            if abs(new_refinance-refinance)+abs(new_equity-equity)<c['funding_tolerance']:break
            refinance=new_refinance;equity=new_equity
        issue_price=p['equity_reference_price']*(1-p['equity_issue_discount'])
        issued=equity/issue_price
        weighted=(a['ytd_weighted_shares']*a['actual_fraction']+shares*duration if actual else shares)+issued*duration/2
        full_revenue=revenue+(a['ytd_revenue'] if actual else 0)
        full_op=op+(known_op if actual else 0)
        full_parent=parent+(known_parent if actual else 0)
        full_da=da+(a['ytd_da'] if actual else 0)
        other_tax_deferral+=tax-cash_tax
        direct=variable_period*direct_share
        variable_sga=variable_period-direct
        future_sga=variable_sga+fixed_period+da
        full_gp=revenue-direct+(a['ytd_gp'] if actual else 0)
        full_sga=future_sga+(a['ytd_sga'] if actual else 0)
        known_other=known_op-(a['ytd_gp']-a['ytd_sga']) if actual else 0
        other_op=known_other+other_profit
        known_sga_cash=a['ytd_sga']-a['ytd_da'] if actual else 0
        row=dict(period_end=f'{year}-12-31',revenue=full_revenue,gross_profit=full_gp,sga=full_sga,other_operating_profit=other_op,
                 ebit=full_op,op_margin=full_op/full_revenue,recurring_parent_profit=full_parent,shares_m=weighted,
                 recurring_eps=full_parent/weighted,cash=before+refinance+equity,debt=debt-repayment+refinance,
                 da=full_da,forward_revenue=revenue,forward_variable_cash_cost=variable_period,forward_fixed_cash_cost=fixed_period,
                 direct_cash_cost=direct+(a['ytd_revenue']-a['ytd_gp'] if actual else 0),
                 variable_sga=variable_sga+known_sga_cash*variable_sga_fraction,
                 fixed_sga=fixed_period+known_sga_cash*(1-variable_sga_fraction),
                 forward_other_profit=other_profit,known_unclassified_q3_other_profit=(a['q3_unclassified_other_profit'] if actual else 0),
                 forward_parent_profit=parent,forward_tax=tax,forward_nci=nci,forward_interest=bank_interest+lease_interest,
                 forward_cash_tax=cash_tax,incremental_future_other_tax_deferral=other_tax_deferral,
                 seller_pv_unwind=unwind,put_cash=put_cash,earnout_cash=earn_cash,fixed_price_cash=fixed_price,
                 remaining_put_cashpoint=pending_put,remaining_earnout_cashpoint=pending_earn,
                 closing_customer_advances=contract,advance_revenue_without_new_cash=earned,customer_refunds=refund,
                 liquidity_reserve=reserve,cash_floor=cash_floor,principal=repayment,draw=refinance,equity_cash=equity,
                 new_shares_m=issued,closing_shares_m=shares+issued,forward_cfo=cfo,forward_capex=capex,
                 opening_lease_debt=a['lease_debt'],replacement_lease_liabilities=lease_principal,closing_lease_debt=a['lease_debt'],
                 elapsed_start_years=elapsed,settlement_midpoint_years=midpoint,next_year_seller_payment_reserve=scheduled_reserve+next_fixed,
                 lease_principal=lease_principal,dividend_cash=0,forecast_cash_period='Q4 only' if actual else 'full year',
                 cash_reconciliation=(before+refinance+equity)-(cash+cfo-capex-lease_principal-put_cash-earn_cash-fixed_price-repayment-(a['tax_payable'] if actual else 0)+refinance+equity))
        rows.append(row);cash=row['cash'];debt=row['debt'];shares+=issued;ar=end_ar;ap=end_ap
        annual_sales=nominal_revenue/duration
        variable=variable*volume*(1+p['variable_input_inflation'])**duration
        fixed=fixed*(1+p['fixed_cost_growth'])**duration
        elapsed+=duration
    return dict(annual=rows,eps_cagr=(rows[-1]['recurring_eps']/rows[0]['recurring_eps'])**(1/3)-1 if rows[0]['recurring_eps']>0 and rows[-1]['recurring_eps']>0 else None)
