"""HAMAKYOREX: source-driven interim-filing refresh of retained financial proxies.

JPY millions, input shares absolute/output shares_m million, yen EPS. Constant pre-adoption lease economics;
not a statutory forecast of FY3/28 lease-standard effects. No guidance inputs.
"""
import copy


def evaluate(inputs,case='base'):
    a=inputs['actual'];p=inputs['cases'][case];c=inputs['conventions']
    h=a['H1'];f=a['FY26'];hp=a['prior_H1']
    if not 0<=p['center_new_contract_fraction']<=p['new_work_envelope']:
        raise ValueError('Unsupported new-work financial envelope')
    shares=p['net_shares'];divshares=shares/1e6
    ordinary=h['ordinary_da'];legacy_gw=sum(s['goodwill'] for s in f['segments'].values())
    gunma_gw=h['gunma_goodwill']/h['gunma_amort_years']
    da_h1=ordinary+legacy_gw/2+gunma_gw/4
    norm_op=h['op']+h['acquisition_advisory_fee']
    normalized_h1_sga=h['sga']-h['acquisition_advisory_fee']
    # Only financial allocations are available; neither ratio is a disclosed segment split.
    sga_cash=(normalized_h1_sga-legacy_gw/2-gunma_gw/4-p['h1_sga_ordinary_da'])/(h['revenue']-norm_op-da_h1)
    sga_da=p['h1_sga_ordinary_da']/ordinary
    opening=dict(cash=h['cash_equivalents'],debt=h['short_debt']+h['long_debt'],lease=p['opening_lease_proxy'],ar=h['ar'],ap=h['ap'],inv=h['inventory'],equity=h['equity'],nci_equity=h['nci_equity'])
    rows=[];segments={};h2segments={};ordinary_shares={}
    committed_h2=sum(q['cash_H2FY27'] for q in p['projects'])
    h2_growth=committed_h2+p['discretionary_growth'][0]*p['growth_capex_multiplier']
    lease_h2_da=p['annual_new_leases']/2/p['lease_life']/4
    extra_h2_da=p['discretionary_growth'][0]*p['growth_capex_multiplier']*(1-p['land_share'])/p['growth_life']/4
    for name in ['center','truck']:
        s=h['segments'][name];prior=hp['segments'][name];fy=f['segments'][name]
        weight=p['ordinary_center_weight'] if name=='center' else 1-p['ordinary_center_weight']
        ordinary_shares[name]=weight
        gw=fy['goodwill']/2+(gunma_gw/4 if name=='center' else 0)
        da1=ordinary*weight+gw
        op1=s['op']+(h['acquisition_advisory_fee'] if name=='center' else 0)
        cash1=s['sales']-op1-da1
        prior_da=(fy['da']+fy['goodwill'])/2
        cash_season=((fy['sales']-prior['sales'])-(fy['op']-prior['op'])-prior_da)/(prior['sales']-prior['op']-prior_da)
        delta=p['h2_'+name+'_seasonal_change'];fixed=p['fixed_share_'+name]
        sales2=s['sales']*(fy['sales']-prior['sales'])/prior['sales']*(1+delta)
        cash2=cash1*cash_season*(fixed+(1-fixed)*(1+delta))*(1+p['h2_unit_cost_pressure'])
        da2=ordinary*weight+fy['goodwill']/2+(gunma_gw/2 if name=='center' else 0)+(lease_h2_da+extra_h2_da)*(p['center_capex_share'] if name=='center' else 1-p['center_capex_share'])
        h2segments[name]=dict(sales=sales2,cash_cost=cash2,da=da2,op=sales2-cash2-da2)
        segments[name]=dict(sales=s['sales']+sales2,cash_cost=cash1+cash2,da=da1+da2,op=op1+sales2-cash2-da2)
    h2_elim=f['op_elimination']/2
    h2op=sum(s['op'] for s in h2segments.values())+h2_elim
    fullsales=sum(s['sales'] for s in segments.values());h2da=sum(s['da'] for s in h2segments.values())
    h2cash=sum(s['cash_cost'] for s in h2segments.values())-h2_elim
    h2nci=(f['nci_net']-hp['nci_net'])*(1+p['nci_pool_growth'])
    def finance(op,da,sales,capex,lease_add,lease_pay,years,nci,dividend_function):
        ar=sales*p['ar_days']/365;ap=sales*p['ap_days']/365;inv=sales*p['inventory_days']/365
        wc=ar-opening['ar']+inv-opening['inv']-(ap-opening['ap'])+p['other_wc_outflow']*years
        repay=min(opening['debt'],p['bank_amortization']*years)
        other=(p['other_nonop']+opening['cash']*p['cash_yield'])*years
        def calc(draw):
            interest=(opening['debt']-repay/2+draw/2)*p['borrow_rate']*years+(opening['lease']+(lease_add-lease_pay)/2)*p['lease_rate']*years
            pbt=op+other-interest;tax=max(pbt,0)*p['tax_rate'];net=pbt-tax;parent=net-nci
            dividend=dividend_function(parent);ncidiv=max(nci,0)*p['nci_payout']
            cfo=net+da-wc;cash=opening['cash']+cfo-capex-lease_pay-dividend-ncidiv-repay+draw
            return dict(cash=cash,parent=parent,tax=tax,interest=interest,pbt=pbt,cfo=cfo,dividends=dividend,nci_dividends=ncidiv)
        lo=0;hi=max(1,p['minimum_cash']-calc(0)['cash'])*2
        for _ in range(100):
            if calc(hi)['cash']>=p['minimum_cash']:break
            hi*=2
        else:raise ValueError('Unfundable liquidity reserve')
        if calc(0)['cash']>=p['minimum_cash']:draw=0
        else:
            for _ in range(100):
                mid=(lo+hi)/2
                if calc(mid)['cash']<p['minimum_cash']:lo=mid
                else:hi=mid
            draw=hi
        z=calc(draw);z.update(debt=opening['debt']-repay+draw,new_borrowing=draw,debt_repayment=repay,lease_debt=opening['lease']+lease_add-lease_pay,lease_principal=lease_pay,new_leases=lease_add,capex=capex,wc_outflow=wc,nci=nci,ar=ar,ap=ap,inv=inv,equity=opening['equity']+z['parent']-z['dividends'],nci_equity=opening['nci_equity']+nci-z['nci_dividends'],other_nonop=other)
        z['fcf_after_leases']=z['cfo']-capex-lease_pay
        z['cash_roll_error']=z['cash']-(opening['cash']+z['cfo']-capex-lease_pay-z['dividends']-z['nci_dividends']-repay+draw)
        z['cash_inclusive_roic_proxy']=(op/years)/((opening['equity']+opening['nci_equity']+opening['debt']+opening['lease']+z['equity']+z['nci_equity']+z['debt']+z['lease_debt'])/2)
        return z
    def advance(z):
        return dict(cash=z['cash'],debt=z['debt'],lease=z['lease_debt'],ar=z['ar'],ap=z['ap'],inv=z['inv'],equity=z['equity'],nci_equity=z['nci_equity'])
    z=finance(h2op,h2da,fullsales,p['h2_maintenance']+h2_growth,p['annual_new_leases']/2,p['annual_lease_principal']/2,.5,h2nci,lambda parent:h['declared_interim_cash'])
    normalization=h['settlement_loss']*(1-p['settlement_tax_benefit'])*p['settlement_parent_attribution']+h['acquisition_advisory_fee']*(1-p['advisory_tax_benefit'])
    parent=h['parent_net']+normalization+z['parent'];fy0shares=(h['weighted_shares']*183+shares*182)/365
    h2gw=legacy_gw/2+gunma_gw/2
    h2sga=h2cash*sga_cash+(h2da-h2gw)*sga_da+h2gw
    gp=h['gross_profit']+(h2op+h2sga);sga=normalized_h1_sga+h2sga
    def row(year,revenue,op,da,parent,weighted,gp,sga,rounding,segs,z,**extra):
        return dict(period_end=f'{year}-03-31',revenue=revenue,gross_profit=gp,cogs=revenue-gp,sga=sga,reported_rounding=rounding,ebit=op,op_margin=op/revenue,da=da,recurring_parent_profit=parent,shares_m=weighted/1e6,recurring_eps=parent*1e6/weighted,cash=z['cash'],debt=z['debt'],lease_debt=z['lease_debt'],segments=segs,funding=z,**extra)
    rows.append(row(2027,fullsales,norm_op+h2op,da_h1+h2da,parent,fy0shares,gp,sga,-1,segments,z,cash_capex=h['cash_capex']+z['capex'],cfo=h['cfo']+z['cfo'],fcf_after_leases=h['cfo']-h['cash_capex']-h['lease_principal']+z['fcf_after_leases'],cash_flow_basis='Full FY3/27: disclosed H1 cash flows plus modeled H2; opening funding is actual September cash.',planned_dps=h['annual_dps'],h1_parent_normalization=normalization,h1_reported_parent=h['parent_net'],h1_recurring_op=norm_op))
    opening=advance(z);cohorts=[];legacy_ordinary=ordinary*2
    kin0=f['kinbutsu']['net_profit']*(1+p['kinbutsu_net_growth']);nci0=h['nci_net']+h2nci
    residual0=nci0-kin0*(1-f['kinbutsu']['parent_ownership'])
    previous_final=(h['annual_dps']-h['interim_dps'])*divshares
    for j,year in enumerate([2028,2029,2030]):
        old=rows[-1];committed=sum(q.get('cash_FY'+str(year-2000),0) for q in p['projects'])
        discretionary=p['discretionary_growth'][j+1]*p['growth_capex_multiplier'];maint=p['maintenance_capex']*(1+p['fixed_inflation'])**j
        growth=committed+discretionary;capex=maint+growth
        cohorts.append(dict(year=year,growth=discretionary*(1-p['land_share']),maint=maint))
        project_da=sum(q['basis']/q['life']*q['fraction_FY'+str(year-2000)] for q in p['projects'])
        lease_da=p['legacy_lease_da']*(1-1/p['lease_life'])**(j+1)+(p['annual_new_leases']/2)/p['lease_life']+sum(p['annual_new_leases']/p['lease_life']*(.5 if yy==year else 1) for yy in range(2028,year+1))
        ordinary_da=(legacy_ordinary-p['legacy_lease_da'])*(1-p['ordinary_da_runoff'])**(j+1)+extra_h2_da*4+sum((q['growth']/p['growth_life']+q['maint']/p['maintenance_life'])*(.5 if q['year']==year else 1) for q in cohorts)+project_da+lease_da
        gw=legacy_gw+gunma_gw;da=ordinary_da+gw;newsegs={}
        for name in ['center','truck']:
            prev=old['segments'][name];fixed=p['fixed_share_'+name]
            if name=='center':
                activity=(1+p['center_volume'])*(1-p['center_churn']);newrev=prev['sales']*p['center_new_contract_fraction'];physical=activity+newrev/prev['sales'];sales=prev['sales']*activity*(1+p['center_price'])+newrev
            else:
                newrev=0;physical=1+p['truck_volume'];sales=prev['sales']*physical*(1+p['truck_price'])
            inflation=p['labor_share']*p['wage_inflation']+(1-p['labor_share'])*p['other_input_inflation']
            recurring=prev['cash_cost']-prev.get('startup_cost',0)
            variable=recurring*(1-fixed)*physical*(1+inflation)*(1-p[name+'_productivity'])
            fixedcash=recurring*fixed*(1+p['fixed_inflation'])+recurring*fixed*newrev/prev['sales']
            startup=newrev*p['startup_rate'];cashcost=variable+fixedcash+startup
            old_gw=f['segments'][name]['goodwill']+(gunma_gw*(.75 if j==0 else 1) if name=='center' else 0)
            ordinary_weight=(prev['da']-old_gw)/max(1,old['da']-(legacy_gw+gunma_gw*(.75 if j==0 else 1)))
            # Allocate new ordinary D&A by the retained prior ordinary financial mix.
            segda=ordinary_da*ordinary_weight+f['segments'][name]['goodwill']+(gunma_gw if name=='center' else 0)
            newsegs[name]=dict(sales=sales,cash_cost=cashcost,da=segda,op=sales-cashcost-segda,startup_cost=startup,new_contract_revenue_proxy=newrev,variable_cash_cost=variable,fixed_cash_cost=fixedcash)
        revenue=sum(s['sales'] for s in newsegs.values());op=sum(s['op'] for s in newsegs.values())+f['op_elimination']
        nci=kin0*(1+p['kinbutsu_net_growth'])**(j+1)*(1-f['kinbutsu']['parent_ownership'])+residual0*(1+p['nci_pool_growth'])**(j+1)
        # The declared46-yen base is retained. Future DPS follows parent-profit changes;
        # cash funds prior final plus current interim, not a same-year payout shortcut.
        def dps(profit):return max(0,old['planned_dps']*(max(profit,0)/max(old['recurring_parent_profit'],1e-9))**p['dividend_profit_elasticity'])
        z=finance(op,da,revenue,capex,p['annual_new_leases'],min(opening['lease']+p['annual_new_leases'],p['annual_lease_principal']),1,nci,lambda profit:previous_final+dps(profit)/2*divshares)
        planned=dps(z['parent']);previous_final=planned/2*divshares
        groupcash=revenue-op-da;sga=groupcash*sga_cash+ordinary_da*sga_da+gw
        rows.append(row(year,revenue,op,da,z['parent'],shares,op+sga,sga,0,newsegs,z,cash_capex=capex,cfo=z['cfo'],fcf_after_leases=z['fcf_after_leases'],cash_flow_basis='Full fiscal year',planned_dps=planned,committed_project_cash=committed,committed_project_da=project_da,ordinary_da=ordinary_da,goodwill_amortization=gw,lease_asset_da=lease_da))
        opening=advance(z)
    return dict(annual=rows,eps_cagr=(rows[-1]['recurring_eps']/rows[0]['recurring_eps'])**(1/3)-1 if rows[-1]['recurring_eps']>0 and rows[0]['recurring_eps']>0 else None,basis='Recurring parent EPS on constant pre-adoption lease economics; no unannounced acquisition earnings.')


if __name__=='__main__':
    from pathlib import Path
    import json
    x=json.loads(Path(__file__).with_name('INPUTS.json').read_text('utf-8'))
    print(json.dumps({k:evaluate(copy.deepcopy(x),k) for k in x['cases']},indent=2))
