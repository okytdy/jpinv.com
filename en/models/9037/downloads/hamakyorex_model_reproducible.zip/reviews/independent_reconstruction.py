"""Independent 9037 arithmetic/funding reconstruction. Never imports candidate model."""
from pathlib import Path
import json, math, copy, hashlib, datetime

ROOT=Path(__file__).resolve().parents[1]
MODEL=ROOT/'model'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))

def reconstruct(data, case='base'):
    h=data['actual']['H1'];f=data['actual']['FY26'];prior=data['actual']['prior_H1'];v=data['cases'][case]
    if not 0<=v['center_new_contract_fraction']<=v['new_work_envelope']:
        raise ValueError('Independently rejected unsupported new-work financial proxy')
    legacy_gw=sum(x['goodwill'] for x in f['segments'].values())
    new_gw=h['gunma_goodwill']/h['gunma_amort_years']
    # Dividend-eligible legal shares are independent of EPS shares. A legacy
    # candidate may use the truncated aggregate proxy: report it as a finding.
    legal_shares=h['issued_shares']-h['treasury_shares']
    # Future constant ordinary shares equal verified current legal shares in
    # every sealed case. Mutation represents an actual new share population.
    eligible_m=v['net_shares']/1e6
    cash=h['cash_equivalents'];bank=h['short_debt']+h['long_debt'];lease=v['opening_lease_proxy']
    receivable=h['ar'];payable=h['ap'];inventory=h['inventory'];equity=h['equity'];minority_equity=h['nci_equity']
    history=[];business={};h2={}
    additions=[]
    first_ordinary=h['ordinary_da']
    h1_total_da=first_ordinary+legacy_gw/2+new_gw/4
    recurrent_h1_op=h['op']+h['acquisition_advisory_fee']
    normalized_h1_sga=h['sga']-h['acquisition_advisory_fee']
    overhead_cash_weight=(normalized_h1_sga-legacy_gw/2-new_gw/4-v['h1_sga_ordinary_da'])/(h['revenue']-recurrent_h1_op-h1_total_da)
    overhead_da_weight=v['h1_sga_ordinary_da']/first_ordinary
    first_lease_add_da=v['annual_new_leases']/2/v['lease_life']/4
    first_disc=v['discretionary_growth'][0]*v['growth_capex_multiplier']
    first_disc_da=first_disc*(1-v['land_share'])/v['growth_life']/4
    for segment in ('center','truck'):
        x=h['segments'][segment];old=f['segments'][segment];py=prior['segments'][segment]
        ow=v['ordinary_center_weight'] if segment=='center' else 1-v['ordinary_center_weight']
        h1_gw=old['goodwill']/2+(new_gw/4 if segment=='center' else 0)
        actual_da=first_ordinary*ow+h1_gw
        recurring_op=x['op']+(h['acquisition_advisory_fee'] if segment=='center' else 0)
        cash_anchor=x['sales']-recurring_op-actual_da
        prior_non_cash=(old['da']+old['goodwill'])/2
        prior_h1_cash=py['sales']-py['op']-prior_non_cash
        prior_h2_cash=old['sales']-py['sales']-old['op']+py['op']-prior_non_cash
        sales_ratio=(old['sales']-py['sales'])/py['sales']
        scale=v['h2_'+segment+'_seasonal_change']
        volume_cost_multiplier=1+(1-v['fixed_share_'+segment])*scale
        h2_sales=x['sales']*sales_ratio*(1+scale)
        h2_cash=cash_anchor*(prior_h2_cash/prior_h1_cash)*volume_cost_multiplier*(1+v['h2_unit_cost_pressure'])
        cohort_weight=v['center_capex_share'] if segment=='center' else 1-v['center_capex_share']
        h2_da=first_ordinary*ow+old['goodwill']/2+(new_gw/2 if segment=='center' else 0)+(first_lease_add_da+first_disc_da)*cohort_weight
        h2[segment]={'sales':h2_sales,'cash_cost':h2_cash,'da':h2_da,'op':h2_sales-h2_cash-h2_da}
        business[segment]={'sales':x['sales']+h2_sales,'cash_cost':cash_anchor+h2_cash,'da':actual_da+h2_da,'op':recurring_op+h2[segment]['op']}

    def fund(op, da, annual_sales, capex, lease_add, lease_pay, duration, nonparent, dividend_rule):
        nonlocal cash,bank,lease,receivable,payable,inventory,equity,minority_equity
        end_ar=annual_sales*v['ar_days']/365;end_ap=annual_sales*v['ap_days']/365;end_inv=annual_sales*v['inventory_days']/365
        working=(end_ar-receivable)+(end_inv-inventory)-(end_ap-payable)+duration*v['other_wc_outflow']
        principal=min(bank,duration*v['bank_amortization'])
        other=duration*(v['other_nonop']+cash*v['cash_yield'])
        def forward(amount):
            bank_interest=duration*v['borrow_rate']*(bank-principal/2+amount/2)
            lease_interest=duration*v['lease_rate']*(lease+(lease_add-lease_pay)/2)
            pretax=op+other-bank_interest-lease_interest
            tax=v['tax_rate']*max(0,pretax)
            consolidated=pretax-tax
            parent=consolidated-nonparent
            paid=dividend_rule(parent)
            outsiders=max(0,nonparent)*v['nci_payout']
            cfo=consolidated+da-working
            closing=cash+cfo-capex-lease_pay-paid-outsiders-principal+amount
            return {'cash':closing,'parent':parent,'tax':tax,'interest':bank_interest+lease_interest,'pbt':pretax,'cfo':cfo,'dividends':paid,'nci_dividends':outsiders}
        no_draw=forward(0)
        if no_draw['cash']>=v['minimum_cash']:draw=0
        else:
            # The cash function is monotonic under the permitted model inputs.
            left=0.;right=1.
            while forward(right)['cash']<v['minimum_cash']:
                right*=4
                if right>1e15:raise ValueError('unfundable independent stress')
            while right-left>1e-10:
                midpoint=(left+right)/2
                if midpoint==left or midpoint==right:break
                if forward(midpoint)['cash']<v['minimum_cash']:left=midpoint
                else:right=midpoint
            draw=right
        z=forward(draw)
        end_bank=bank-principal+draw;end_lease=lease+lease_add-lease_pay
        end_equity=equity+z['parent']-z['dividends'];end_nci_equity=minority_equity+nonparent-z['nci_dividends']
        capital0=equity+minority_equity+bank+lease
        capital1=end_equity+end_nci_equity+end_bank+end_lease
        z.update(debt=end_bank,new_borrowing=draw,debt_repayment=principal,lease_debt=end_lease,lease_principal=lease_pay,new_leases=lease_add,capex=capex,wc_outflow=working,nci=nonparent,ar=end_ar,ap=end_ap,inv=end_inv,equity=end_equity,nci_equity=end_nci_equity,other_nonop=other,fcf_after_leases=z['cfo']-capex-lease_pay,cash_roll_error=z['cash']-(cash+z['cfo']-capex-lease_pay-z['dividends']-z['nci_dividends']-principal+draw),cash_inclusive_roic_proxy=(op/duration)/((capital0+capital1)/2))
        cash,bank,lease=z['cash'],end_bank,end_lease
        receivable,payable,inventory=end_ar,end_ap,end_inv
        equity,minority_equity=end_equity,end_nci_equity
        return z

    h2_op=sum(x['op'] for x in h2.values())+f['op_elimination']/2
    h2_da=sum(x['da'] for x in h2.values())
    sales=sum(x['sales'] for x in business.values())
    h2_nci=(f['nci_net']-prior['nci_net'])*(1+v['nci_pool_growth'])
    capex=v['h2_maintenance']+sum(q['cash_H2FY27'] for q in v['projects'])+first_disc
    z=fund(h2_op,h2_da,sales,capex,v['annual_new_leases']/2,v['annual_lease_principal']/2,.5,h2_nci,lambda x:h['declared_interim_cash'])
    adjustment=h['settlement_loss']*(1-v['settlement_tax_benefit'])*v['settlement_parent_attribution']+h['acquisition_advisory_fee']*(1-v['advisory_tax_benefit'])
    parent=h['parent_net']+adjustment+z['parent'];weighted=(h['weighted_shares']*183+v['net_shares']*182)/365
    group_h2_cash=sum(x['cash_cost'] for x in h2.values())-f['op_elimination']/2
    h2_gw=legacy_gw/2+new_gw/2
    h2_sga=group_h2_cash*overhead_cash_weight+(h2_da-h2_gw)*overhead_da_weight+h2_gw
    sga=normalized_h1_sga+h2_sga;gross=h['gross_profit']+h2_op+h2_sga
    history.append({'period_end':'2027-03-31','revenue':sales,'gross_profit':gross,'cogs':sales-gross,'sga':sga,'reported_rounding':-1,'ebit':recurrent_h1_op+h2_op,'op_margin':(recurrent_h1_op+h2_op)/sales,'da':h1_total_da+h2_da,'recurring_parent_profit':parent,'shares_m':weighted/1e6,'recurring_eps':parent*1e6/weighted,'cash':z['cash'],'debt':z['debt'],'lease_debt':z['lease_debt'],'segments':business,'funding':z,'cash_capex':h['cash_capex']+capex,'cfo':h['cfo']+z['cfo'],'fcf_after_leases':h['cfo']-h['cash_capex']-h['lease_principal']+z['fcf_after_leases'],'planned_dps':h['annual_dps'],'h1_parent_normalization':adjustment,'h1_reported_parent':h['parent_net'],'h1_recurring_op':recurrent_h1_op})
    first_nci=h['nci_net']+h2_nci
    kin_start=f['kinbutsu']['net_profit']*(1+v['kinbutsu_net_growth'])
    minority_fraction=1-f['kinbutsu']['parent_ownership']
    residual=first_nci-kin_start*minority_fraction
    prior_final=(h['annual_dps']-h['interim_dps'])*eligible_m
    for step in range(1,4):
        year=2027+step
        old=history[-1];new_business={}
        discretionary=v['discretionary_growth'][step]*v['growth_capex_multiplier']
        maintenance=v['maintenance_capex']*(1+v['fixed_inflation'])**(step-1)
        named_cash=sum(q.get('cash_FY'+str(year-2000),0) for q in v['projects'])
        additions.append((year,discretionary*(1-v['land_share']),maintenance))
        named_da=sum(q['basis']/q['life']*q['fraction_FY'+str(year-2000)] for q in v['projects'])
        legacy_lease=v['legacy_lease_da']*(1-1/v['lease_life'])**step
        lease_cohorts=v['annual_new_leases']/2/v['lease_life']+sum(v['annual_new_leases']/v['lease_life']*(.5 if origin==year else 1) for origin in range(2028,year+1))
        lease_da=legacy_lease+lease_cohorts
        old_nonlease=(2*first_ordinary-v['legacy_lease_da'])*(1-v['ordinary_da_runoff'])**step
        cash_cohorts=sum((growth/v['growth_life']+maint/v['maintenance_life'])*(.5 if origin==year else 1) for origin,growth,maint in additions)
        # H2 discretionary assets commissioned before this horizon remain in
        # service: full annual D&A is four times their first quarter convention.
        ordinary_da=old_nonlease+cash_cohorts+named_da+lease_da+first_disc_da*4
        all_gw=legacy_gw+new_gw
        total_da=ordinary_da+all_gw
        previous_gw=legacy_gw+new_gw*(.75 if step==1 else 1)
        previous_ordinary=old['da']-previous_gw
        for segment in ('center','truck'):
            x=old['segments'][segment];fixed=v['fixed_share_'+segment]
            if segment=='center':
                existing=(1+v['center_volume'])*(1-v['center_churn'])
                new_work=x['sales']*v['center_new_contract_fraction']
                sales=x['sales']*existing*(1+v['center_price'])+new_work
                workload=existing+new_work/x['sales']
            else:
                new_work=0;workload=1+v['truck_volume'];sales=x['sales']*workload*(1+v['truck_price'])
            unit_inflation=v['labor_share']*v['wage_inflation']+(1-v['labor_share'])*v['other_input_inflation']
            old_cost=x['cash_cost']-x.get('startup_cost',0)
            variable=old_cost*(1-fixed)*workload*(1+unit_inflation)*(1-v[segment+'_productivity'])
            fixedcash=old_cost*fixed*(1+v['fixed_inflation']+new_work/x['sales'])
            startup=new_work*v['startup_rate'];cost=variable+fixedcash+startup
            old_segment_gw=f['segments'][segment]['goodwill']+(new_gw*(.75 if step==1 else 1) if segment=='center' else 0)
            ordinary_mix=(x['da']-old_segment_gw)/max(1,previous_ordinary)
            segment_da=ordinary_da*ordinary_mix+f['segments'][segment]['goodwill']+(new_gw if segment=='center' else 0)
            new_business[segment]={'sales':sales,'cash_cost':cost,'da':segment_da,'op':sales-cost-segment_da,'startup_cost':startup,'new_contract_revenue_proxy':new_work,'variable_cash_cost':variable,'fixed_cash_cost':fixedcash}
        sales=sum(x['sales'] for x in new_business.values());op=sum(x['op'] for x in new_business.values())+f['op_elimination']
        nci=kin_start*(1+v['kinbutsu_net_growth'])**step*minority_fraction+residual*(1+v['nci_pool_growth'])**step
        def planned_dps(profit):return max(0,old['planned_dps']*(max(0,profit)/max(old['recurring_parent_profit'],1e-9))**v['dividend_profit_elasticity'])
        final_to_pay=prior_final
        z=fund(op,total_da,sales,maintenance+named_cash+discretionary,v['annual_new_leases'],min(lease+v['annual_new_leases'],v['annual_lease_principal']),1,nci,lambda profit:final_to_pay+planned_dps(profit)*eligible_m/2)
        dps=planned_dps(z['parent']);prior_final=dps*eligible_m/2
        group_cash=sales-op-total_da
        sga=group_cash*overhead_cash_weight+ordinary_da*overhead_da_weight+all_gw
        history.append({'period_end':f'{year}-03-31','revenue':sales,'gross_profit':op+sga,'cogs':sales-op-sga,'sga':sga,'reported_rounding':0,'ebit':op,'op_margin':op/sales,'da':total_da,'recurring_parent_profit':z['parent'],'shares_m':v['net_shares']/1e6,'recurring_eps':z['parent']*1e6/v['net_shares'],'cash':z['cash'],'debt':z['debt'],'lease_debt':z['lease_debt'],'segments':new_business,'funding':z,'cash_capex':maintenance+named_cash+discretionary,'cfo':z['cfo'],'fcf_after_leases':z['fcf_after_leases'],'planned_dps':dps,'committed_project_cash':named_cash,'committed_project_da':named_da,'ordinary_da':ordinary_da,'goodwill_amortization':all_gw,'lease_asset_da':lease_da})
    return {'annual':history,'eps_cagr':(history[-1]['recurring_eps']/history[0]['recurring_eps'])**(1/3)-1 if history[-1]['recurring_eps']>0 and history[0]['recurring_eps']>0 else None}

def numeric_differences(independent,reference,location=''):
    differences=[]
    if isinstance(independent,dict):
        for key,value in independent.items():
            if key not in reference:continue
            differences+=numeric_differences(value,reference[key],location+'/'+str(key))
    elif isinstance(independent,list):
        for index,(x,y) in enumerate(zip(independent,reference)):
            differences+=numeric_differences(x,y,location+'/'+str(index))
    elif isinstance(independent,(int,float)) and not isinstance(independent,bool):
        error=abs(independent-reference)
        if error>1e-7:differences.append({'path':location,'independent':independent,'candidate':reference,'absolute_error':error})
    return differences

def changed(data,changes):
    result=copy.deepcopy(data)
    for path,value in changes.items():
        components=path.strip('/').split('/');target=result
        for key in components[:-1]:target=target[int(key)] if isinstance(target,list) else target[key]
        target[components[-1]]=value
    return result

if __name__=='__main__':
    inputs=read(MODEL/'INPUTS.json');expected=read(MODEL/'OUTPUTS.json');contract=read(MODEL/'ECONOMIC_CONTRACT.json')
    cases={name:reconstruct(inputs,name) for name in inputs['cases']}
    mismatches=numeric_differences(cases,expected['cases'])
    sensitivities=[]
    for scenario in read(MODEL/'SENSITIVITIES.json')['sensitivities']:
        result=reconstruct(changed(inputs,scenario['input_changes']))
        rows=result['annual'];metrics={'fy0_eps':rows[0]['recurring_eps'],'fy3_eps':rows[-1]['recurring_eps'],'eps_cagr':result['eps_cagr'],'fy1_op_change':rows[1]['ebit']-rows[0]['ebit'],'target_cash':rows[-1]['cash'],'target_debt':rows[-1]['debt']}
        errors=numeric_differences(metrics,scenario)
        sensitivities.append({'label':scenario['label'],'metrics':metrics,'differences':errors})
        mismatches+=errors
    later_discretionary=copy.deepcopy(inputs['cases']['base']['discretionary_growth']);later_discretionary[1]+=3000
    first_discretionary=copy.deepcopy(inputs['cases']['base']['discretionary_growth']);first_discretionary[0]+=3000
    delayed_projects=copy.deepcopy(inputs['cases']['base']['projects']);delayed_projects[1]['fraction_FY28']=0
    stress_specs={'no_future_new_contracts':{'/cases/base/center_new_contract_fraction':0},'lost_center_work':{'/cases/base/center_volume':-.2,'/cases/base/center_churn':.1,'/cases/base/center_new_contract_fraction':0},'liquidity_reserve70bn':{'/cases/base/minimum_cash':70000},'share_denominator_plus10pct':{'/cases/base/net_shares':inputs['cases']['base']['net_shares']*1.1},'settlement_no_tax_benefit':{'/cases/base/settlement_tax_benefit':0},'extra_FY28_discretionary_3bn':{'/cases/base/discretionary_growth':later_discretionary},'extra_H2_discretionary_3bn':{'/cases/base/discretionary_growth':first_discretionary},'Narita_DA_delayed_after_FY28':{'/cases/base/projects':delayed_projects},'higher_minority_claims':{'/cases/base/nci_pool_growth':.14}}
    stresses={name:reconstruct(changed(inputs,spec)) for name,spec in stress_specs.items()}
    h=inputs['actual']['H1']
    checks={'source_CFE':h['cash_equivalents']==23620,'historical_FCF_after_leases':h['cfo']-h['cash_capex']-h['lease_principal']==3192,'actual_H1_ordinary_DA':h['ordinary_da']==3781,'GW_H1':h['gunma_goodwill']/h['gunma_amort_years']/4==20.4,'GW_H2':h['gunma_goodwill']/h['gunma_amort_years']/2==40.8,'share_actual':h['issued_shares']-h['treasury_shares']==74050222,'all_numeric_outcomes_match':not mismatches,'all_cash_rolls':all(abs(x['funding']['cash_roll_error'])<1e-7 for result in cases.values() for x in result['annual']),'no_negative_tax_cash_in_stress':all(x['funding']['tax']>=0 for result in stresses.values() for x in result['annual'])}
    checks.update(extra_FY28_capex_changes_DA=stresses['extra_FY28_discretionary_3bn']['annual'][1]['da']>cases['base']['annual'][1]['da'],extra_H2_capex_changes_DA=stresses['extra_H2_discretionary_3bn']['annual'][0]['da']>cases['base']['annual'][0]['da'],extra_H2_cohort_continues_next_year=abs(stresses['extra_H2_discretionary_3bn']['annual'][1]['da']-cases['base']['annual'][1]['da']-3000*(1-inputs['cases']['base']['land_share'])/inputs['cases']['base']['growth_life'])<1e-7,Narita_commissioning_changes_DA=stresses['Narita_DA_delayed_after_FY28']['annual'][1]['da']<cases['base']['annual'][1]['da'],extra_minority_claim_lowers_EPS=stresses['higher_minority_claims']['annual'][-1]['recurring_eps']<cases['base']['annual'][-1]['recurring_eps'],extra_funding_charges_interest=stresses['liquidity_reserve70bn']['annual'][0]['funding']['interest']>cases['base']['annual'][0]['funding']['interest'])
    output={'status':'PASS' if all(checks.values()) else 'FAIL','reviewer':'/root/hamakyorex_reviewer','reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'forecast_run_id':contract['run_id'],'contract_sha256':sha(MODEL/'ECONOMIC_CONTRACT.json'),'model_sha256':sha(MODEL/'model.py'),'input_sha256':sha(MODEL/'INPUTS.json'),'output_sha256':sha(MODEL/'OUTPUTS.json'),'checks':checks,'differences':mismatches,'cases':cases,'sensitivities':sensitivities,'independent_stress_inputs':stress_specs,'independent_stresses':stresses,'legal_dividend_shares':h['issued_shares']-h['treasury_shares'],'rounded_aggregate_dividend_share_proxy':h['declared_interim_cash']/h['interim_dps']*1e6,'arithmetic_only_note':'PASS here verifies independent reconstruction, not economic approval. Sources and causal assumptions are judged separately.'}
    (ROOT/'reviews/INDEPENDENT_RECONSTRUCTION.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':output['status'],'checks':checks,'difference_count':len(mismatches),'first_differences':mismatches[:12],'base_eps':[x['recurring_eps'] for x in cases['base']['annual']],'stress_final_eps':{k:v['annual'][-1]['recurring_eps'] for k,v in stresses.items()}},indent=2))
