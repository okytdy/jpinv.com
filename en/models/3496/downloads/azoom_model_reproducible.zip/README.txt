Validate and independently replay every case without overwriting the reviewed files:
python -c "from tools.forecast_evidence import validate_run; print(validate_run('model/ECONOMIC_CONTRACT.json', replay=True))"
Units: Use the explicit input/output field labels and the model executable documentation. Follow explicit field names for input/output share units. Guidance is not an input.
