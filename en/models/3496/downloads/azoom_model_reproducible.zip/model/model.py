"""AZoom independent operating forecast. JPY millions except shares/units/EPS.
No guidance imports. FY28 onward remains on the FY26 lease-accounting basis.
Run: python model.py --inputs inputs.json --out outputs.json
"""
from pathlib import Path
import json, copy, argparse, math

def evaluate(inp,case):
    a=inp['actual']; c=inp['cases'][case]; k=inp['conventions']
    n=len(c['hires']); assert n==4
    for key,values in c.items():
        if isinstance(values,list) and len(values)!=n:raise ValueError('Missing annual driver: '+key)
    if not 0<a['occupied_end']<=a['contracted_end']:raise ValueError('Impossible opening occupancy')
    stock=a['contracted_end']; hc=a['headcount_end']; cash=a['cash']; debt=a['debt']; equity=a['equity']
    cg=a['visual_sales']; referral=a['referral_sales']; other=a['other_sales']; rent_rate=a['owner_rent_proxy']/a['average_contracted_proxy']
    labor=a['idle_labor_proxy']; overhead=a['idle_cash_overhead_proxy']; cg_fixed=a['visual_fixed_cash_proxy']
    historical_hc_avg=a['headcount_average_proxy']; original_labor_rate=labor/historical_hc_avg
    tenant_rate=None; deferred_recovery=0
    software_cohorts=[]; tangible_cohorts=[]; cip_left=a['software_cip']; software_net=a['software_live']; tangible_net=a['tangible_net']
    wc_prev={name:a[name] for name in ['receivables','prepaid_rent','owner_deposits','customer_deposits','deferred_revenue','contract_liabilities','payables']}
    tax_payable=a['tax_payable']; rows=[]; cumulative_draw=0
    for i in range(n):
        year=k['first_year']+i; open_stock=stock; open_hc=hc; open_cash=cash; open_debt=debt; open_equity=equity
        hc+=c['hires'][i]; avg_hc=(open_hc+hc)/2
        capacity=avg_hc*c['net_adds_per_group_employee'][i]
        net_adds=round(min(capacity,c['obtainable_net_adds_cap'][i])); stock+=net_adds
        avg_stock=(open_stock+stock)/2
        occ=c['average_occupancy'][i]
        if not 0<=occ<=1:raise ValueError('Impossible occupancy')
        occupied=avg_stock*occ
        old_rent_rate=rent_rate
        rent_rate*=1+c['owner_rent_per_space_growth'][i]
        # Fixed pricing denominator: vacancy stress never manufactures a higher price.
        recovery_unit=(rent_rate-old_rent_rate)*c['owner_cost_dollar_recovery'][i]/a['pricing_reference_occupancy']
        if tenant_rate is None: tenant_rate=c['initial_service_yield']
        tenant_rate=tenant_rate*(1+c['service_mix_growth'][i])+deferred_recovery+recovery_unit*c['recovery_recognition_fraction'][i]
        deferred_recovery=recovery_unit*(1-c['recovery_recognition_fraction'][i])
        service_rate=tenant_rate
        core=occupied*service_rate
        referral*=1+c['referral_growth'][i];other*=1+c['other_growth'][i];cg*=1+c['visual_growth'][i]
        idle_sales=core+referral+other;revenue=idle_sales+cg
        rent=avg_stock*rent_rate
        idle_other_direct=idle_sales*a['idle_other_direct_rate']
        cg_direct=cg*a['visual_variable_cost_rate']
        cogs=rent+idle_other_direct+cg_direct; gp=revenue-cogs
        labor_rate=original_labor_rate*math.prod(1+x for x in c['wage_inflation'][:i+1]);labor=avg_hc*labor_rate
        overhead=overhead*(1+c['idle_overhead_growth'][i])+c['security_extra'][i]
        cg_fixed*=1+c['visual_fixed_growth'][i]
        commissioned=a['software_cip']*c['opening_cip_commission_fraction'][i]
        if commissioned>cip_left+1e-7:raise ValueError('Commissioning exceeds CIP')
        cip_left-=commissioned
        software_cohorts.append((i,commissioned,c['software_life'][i]))
        software_cohorts.append((i,c['software_capex'][i],c['software_life'][i]))
        tangible_cohorts.append((i,c['tangible_capex'][i],c['tangible_life'][i]))
        def cohort_da(cohorts):
            return sum(value/life*(0.5 if i-start in [0,life] else 1) for start,value,life in cohorts if 0<=i-start<=life)
        sw_da=(a['software_live']/a['software_live_remaining_life'] if i<a['software_live_remaining_life'] else 0)+cohort_da(software_cohorts)
        tang_da=(a['tangible_net']/a['tangible_remaining_life'] if i<a['tangible_remaining_life'] else 0)+cohort_da(tangible_cohorts)
        goodwill=min(a['goodwill_annual'],max(0,a['goodwill_net']-i*a['goodwill_annual']))
        da=sw_da+tang_da+goodwill
        software_net+=commissioned+c['software_capex'][i]-sw_da;tangible_net+=c['tangible_capex'][i]-tang_da
        viz_da=a['visual_da']*cg/a['visual_sales']; idle_da=da-viz_da
        sga=labor+overhead+cg_fixed+da
        ebit=gp-sga;viz_ebit=cg-cg_direct-cg_fixed-viz_da
        idle_ebit=ebit-viz_ebit
        principal=min(debt,c['principal'][i]);debt-=principal
        interest= (open_debt+debt)/2*c['debt_interest_rate'][i]
        income=open_cash*c['cash_yield'][i];nonop=income-interest-c['other_nonop_cost'][i]
        pbt=ebit+nonop;tax=max(0,pbt)*c['tax_rate'][i]
        viz_parent_np=viz_ebit*(1-c['tax_rate'][i])*a['visual_net_profit_conversion']
        minority=viz_parent_np*a['minority_ownership'];profit=pbt-tax-minority
        shares=c['shares_m'][i];eps=profit/shares
        wc={
            'receivables':revenue*a['receivables']/a['revenue'],
            'prepaid_rent':rent*a['prepaid_rent']/a['owner_rent_proxy'],
            'owner_deposits':stock*a['owner_deposits']/a['contracted_end'],
            'customer_deposits':stock*occ*a['customer_deposits']/a['occupied_end'],
            'deferred_revenue':core*a['deferred_revenue']/a['core_sales'],
            'contract_liabilities':core*a['contract_liabilities']/a['core_sales'],
            'payables':(cogs+labor+overhead+cg_fixed)*a['payables']/(a['cogs']+a['sga']-a['da'])
        }
        wc_delta=sum((wc[x]-wc_prev[x])*(1 if x in ['receivables','prepaid_rent','owner_deposits'] else -1) for x in wc)
        capex=c['software_capex'][i]+c['tangible_capex'][i]
        prior_dps=a['dividend_dps'] if i==0 else rows[-1]['dps']
        def funding(draw):
            draw_interest=draw*c['debt_interest_rate'][i]*0.5
            final_pbt=ebit+nonop-draw_interest
            final_tax=max(0,final_pbt)*c['tax_rate'][i]
            payable=final_tax*a['tax_payable']/a['current_tax_charge']
            paid=max(0,final_tax+tax_payable-payable)
            parent_profit=final_pbt-final_tax-minority
            # Declared DPS / average equity DOE, with half-year cash timing.
            target=c['doe_target'][i]
            doe_dps=target*(open_equity+0.5*parent_profit-0.25*prior_dps*shares)/(shares*(1+0.25*target))
            dps=c['dividend_dps'][i] if i==0 else max(0,prior_dps,doe_dps)
            dividend=(prior_dps+dps)*0.5*shares
            cfo=parent_profit+minority+da-wc_delta+final_tax-paid
            fcf=cfo-capex-c['office_deposit_cash'][i]
            cash=open_cash+fcf-dividend-principal+draw
            return cash,draw_interest,final_pbt,final_tax,payable,paid,parent_profit,cfo,fcf,dividend,dps
        draw=0
        if funding(0)[0]<c['minimum_cash'][i]:
            lo,hi=0,1
            while funding(hi)[0]<c['minimum_cash'][i]:
                hi*=2
                if hi>1e9:raise ValueError('Unfundable stress')
            for _ in range(80):
                mid=(lo+hi)/2
                if funding(mid)[0]<c['minimum_cash'][i]:lo=mid
                else:hi=mid
            draw=hi
        cash,draw_interest,pbt,tax,next_tax_payable,tax_cash,profit,cfo,fcf,dividend,dps=funding(draw)
        eps=profit/shares;debt+=draw;cumulative_draw+=draw
        equity+=profit-dividend
        capital_start=open_equity+open_debt;capital_end=equity+debt
        roce=ebit/((capital_start+capital_end)/2) if capital_start+capital_end>0 else None
        row=dict(period_end=f'{year}-09-30',revenue=revenue,core_sales=core,referral_sales=referral,other_sales=other,visual_sales=cg,
          idle_sales=idle_sales,contracted_open=open_stock,net_adds=net_adds,contracted_end=stock,average_contracted=avg_stock,
          average_occupancy=occ,average_occupied=occupied,headcount_end=hc,average_headcount=avg_hc,acquisition_capacity=capacity,
          active_constraint='capacity' if capacity<=c['obtainable_net_adds_cap'][i] else 'obtainable supply / execution',
          service_rate=service_rate,owner_unit_cost_increase=rent_rate-old_rent_rate,tenant_recovery_unit=recovery_unit,deferred_recovery_unit=deferred_recovery,owner_rent=rent,owner_rent_rate=rent_rate,idle_other_direct=idle_other_direct,visual_direct=cg_direct,
          cogs=cogs,gross_profit=gp,labor=labor,idle_overhead=overhead,visual_fixed=cg_fixed,da=da,sga=sga,ebit=ebit,
          idle_ebit=idle_ebit,visual_ebit=viz_ebit,margin=ebit/revenue,interest=interest+draw_interest,nonop=nonop-draw_interest,
          pbt=pbt,tax=tax,tax_rate=c['tax_rate'][i],minority=minority,recurring_parent_profit=profit,recurring_eps=eps,
          shares_m=shares,cash_open=open_cash,cash=cash,debt=debt,principal=principal,draw=draw,dividend_cash=dividend,
          dps=dps,doe=dps*shares/((open_equity+equity)/2) if open_equity+equity>0 else None,
          uncommitted_financing_required=max(0,cumulative_draw-a['last_disclosed_undrawn_facility']),
          cfo=cfo,capex=capex,office_deposit_cash=c['office_deposit_cash'][i],fcf=fcf,wc_delta=wc_delta,
          tax_cash=tax_cash,tax_payable=next_tax_payable,equity=equity,roce_cash_inclusive_equity_plus_debt=roce,software_net=software_net,software_cip=cip_left,
          tangible_net=tangible_net,commissioned_cip=commissioned,software_da=sw_da,tangible_da=tang_da,goodwill_da=goodwill,**wc)
        if min(software_net,tangible_net,cip_left)<-1e-6:raise ValueError('Negative asset roll-forward')
        rows.append(row);wc_prev=wc;tax_payable=next_tax_payable
    return dict(annual=rows,eps_cagr_FY27_FY30=(rows[-1]['recurring_eps']/rows[0]['recurring_eps'])**(1/3)-1 if min(rows[-1]['recurring_eps'],rows[0]['recurring_eps'])>0 else None,
       eps_cagr_reported_FY26_FY29=(rows[2]['recurring_eps']/a['reported_eps'])**(1/3)-1 if rows[2]['recurring_eps']>0 else None)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--inputs',default='inputs.json');p.add_argument('--out',default='outputs.json');arg=p.parse_args()
    inp=json.loads(Path(arg.inputs).read_text('utf-8'));out={'basis':'FY26 lease accounting / recurring parent earnings; FY28 adoption effects unquantified','cases':{x:evaluate(inp,x) for x in ['bear','base','bull']}}
    Path(arg.out).write_text(json.dumps(out,indent=2,ensure_ascii=False),'utf-8')
