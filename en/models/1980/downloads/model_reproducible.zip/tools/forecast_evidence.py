"""Validate evidence lineage and human economic signoff, separately from arithmetic.

This checks records and hashes. It cannot decide whether an economic inference
is reasonable; an identified independent reviewer must make that judgment.
"""
from pathlib import Path
import copy,hashlib,importlib.util,json,math,sys

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def evidence_digest(contract):
    payload={k:v for k,v in contract.items() if k!='independent_review'}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()

def validate_economic_contract(contract_path,input_path,*,require_review=True):
    contract_path,input_path=Path(contract_path),Path(input_path)
    root=contract_path.parent
    c=json.loads(contract_path.read_text(encoding='utf-8'))
    inp=json.loads(input_path.read_text(encoding='utf-8'))
    if c.get('schema')=='evidence_grounded_forecast_v2':
        return validate_run(contract_path,require_review=require_review)
    if c.get('schema')!='evidence_balanced_forecast_v1':raise ValueError('Unknown economic evidence contract')
    if c.get('input_sha256')!=sha(input_path):raise ValueError('Economic review invalidated: inputs changed')
    if c.get('model_sha256')!=sha(root/'model.py'):raise ValueError('Economic review invalidated: executable changed')
    if c.get('central_case_role')!='best_supported_expectation':raise ValueError('Stress/resilience case cannot be promoted as central')
    if c.get('unresolved_material_findings'):raise ValueError('Material economic findings unresolved')
    sources={s['id']:s for s in c['sources']}
    for s in sources.values():
        if not s.get('url','').startswith('https://') or not s.get('date'):raise ValueError('Missing primary source identity/date')
        if sha(root/s['archive'])!=s['sha256']:raise ValueError('Primary source archive changed: '+s['id'])
    coverage=set()
    for a in c['assumptions']:
        keys=a.get('input_keys',[])
        if not keys:raise ValueError('Assumption lacks executable input mapping')
        coverage.update(keys)
        if a.get('kind') not in ['calculated_actual','house_inference','house_assumption']:raise ValueError('Unclassified assumption')
        for field in ['observed_fact','derivation','central_case_reason','alternative','falsifier','range']:
            if not a.get(field):raise ValueError('Missing '+field+' for '+a['id'])
        if a.get('justification_basis') in ['inherited_default','prudence','generic_normalization']:
            raise ValueError('Arbitrary assumption cannot enter central case: '+a['id'])
        if a.get('justification_basis') not in ['issuer_evidence_and_explicit_commercial_judgment','reported_actual']:
            raise ValueError('Missing/unknown economic justification: '+a['id'])
        refs=a.get('evidence',[])
        if not refs or any(e.get('source_id') not in sources or not e.get('locator') for e in refs):
            raise ValueError('Missing evidence/locator for '+a['id'])
        for k in keys:
            if k not in inp['cases']['base']:raise ValueError('Unknown input '+k)
        if {k:inp['cases']['base'][k] for k in keys}!=a.get('base_values'):
            raise ValueError('Assumption register differs from executable inputs')
    if coverage!=set(inp['cases']['base']):raise ValueError('Material inputs missing from economic review: '+str(set(inp['cases']['base'])-coverage))
    review=c.get('independent_review',{})
    if require_review:
        if review.get('status')!='approved' or not review.get('reviewer') or not review.get('economic_judgment'):
            raise ValueError('Independent economic approval required; arithmetic PASS is insufficient')
        rp=root/review['archive']
        if sha(rp)!=review['sha256']:raise ValueError('Independent review archive changed')
        r=json.loads(rp.read_text(encoding='utf-8'))
        if r.get('status')!='approved' or r.get('input_sha256')!=c['input_sha256'] or r.get('model_sha256')!=c['model_sha256']:
            raise ValueError('Independent review not bound to current model and inputs')
        if r.get('evidence_sha256')!=evidence_digest(c):raise ValueError('Economic assumptions/evidence changed since independent review')
    return {'status':'PASS_ECONOMIC_RECORD_AND_REVIEW' if require_review else 'PASS_RECORD_PENDING_REVIEW','assumptions':len(c['assumptions']),'sources':len(sources)}


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def leaf_values(value,prefix=''):
    """JSON pointers cover actual anchors as well as all scenario assumptions."""
    if isinstance(value,dict):
        result={}
        for key,item in value.items():
            escaped=str(key).replace('~','~0').replace('/','~1')
            result.update(leaf_values(item,prefix+'/'+escaped))
        return result
    if isinstance(value,list):
        result={}
        for index,item in enumerate(value):result.update(leaf_values(item,prefix+'/'+str(index)))
        return result
    if isinstance(value,float) and not math.isfinite(value):raise ValueError('Nonfinite forecast input')
    return {prefix:value}


def pointer(value,path):
    for key in path.strip('/').split('/'):
        key=key.replace('~1','/').replace('~0','~')
        value=value[int(key)] if isinstance(value,list) else value[key]
    return value


def run_digest(contract):
    return canonical_hash({k:v for k,v in contract.items() if k!='independent_review'})


def _resolved(root,relative):
    path=(root/relative).resolve()
    # A run may retain sibling sources/reviews, but never arbitrary host files.
    path.relative_to(root.parent.resolve())
    if not path.is_file():raise ValueError('Missing run artifact: '+str(path))
    return path


def validate_run(contract_path,*,require_review=True,replay=False):
    """Validate a complete new forecast run; v1 records cannot enter this route.

    Completeness is mechanical. The independent reviewer still judges the
    economics, including whether an explicit margin proxy is defensible.
    """
    cp=Path(contract_path).resolve();root=cp.parent
    c=json.loads(cp.read_text('utf-8'))
    if c.get('schema')!='evidence_grounded_forecast_v2':raise ValueError('A complete v2 operating/evidence run is required; annual totals alone are insufficient')
    if c.get('central_case_role')!='best_supported_expectation':raise ValueError('Central-case economic role missing')
    if c.get('unresolved_material_findings'):raise ValueError('Unresolved material economic findings')
    required={'model','inputs','outputs','assumptions','sources','bridges','mechanisms'}
    if not required<=set(c.get('files',{})):raise ValueError('Incomplete forecast run artifacts')
    files={}
    for role,record in c['files'].items():
        files[role]=_resolved(root,record['path'])
        if sha(files[role])!=record.get('sha256'):raise ValueError('Run artifact changed: '+role)
    inp=json.loads(files['inputs'].read_text('utf-8'))
    assumptions=json.loads(files['assumptions'].read_text('utf-8'))
    sources=json.loads(files['sources'].read_text('utf-8'))
    source_map={s['id']:s for s in sources['sources']}
    freshness=sources.get('review',{})
    if not freshness.get('reviewed_at') or not freshness.get('correction_search_urls') or not freshness.get('correction_disposition'):
        raise ValueError('Current issuer/correction review is missing')
    for source in source_map.values():
        for field in ['url','issued_on','period_end','archive','sha256']:
            if not source.get(field):raise ValueError('Incomplete source identity/period: '+source['id'])
        if not source['url'].startswith('https://'):raise ValueError('Primary source URL required')
        if sha(_resolved(root,source['archive']))!=source['sha256']:raise ValueError('Source archive changed: '+source['id'])
    covered={}
    for a in assumptions:
        if a.get('kind') not in {'reported_actual','calculated_actual','house_inference','house_assumption','accounting_convention'}:
            raise ValueError('Unclassified input: '+a.get('id','?'))
        for field in ['units','observed_anchor','derivation','reason_for_base','timing','alternative','range','falsifier','mechanism','evidence','path_values']:
            if a.get(field) in (None,'',[],{}):raise ValueError('Missing '+field+' for '+a.get('id','?'))
        if a.get('justification_basis') in {'inherited_default','prudence','generic_normalization','target_calibration','output_recipe'}:
            raise ValueError('Unsupported economic justification: '+a['id'])
        if a.get('justification_basis') not in {'reported_actual','issuer_evidence_and_explicit_commercial_judgment','accounting_identity'}:
            raise ValueError('Unknown justification basis: '+a['id'])
        if any(e.get('source_id') not in source_map or not e.get('locator') or not e.get('passage') for e in a['evidence']):
            raise ValueError('Source passage/locator missing: '+a['id'])
        for path,expected in a['path_values'].items():
            actual=pointer(inp,path)
            if actual!=expected:raise ValueError('Assumption differs from executable input: '+path)
            for leaf,value in leaf_values(actual,path).items():
                if leaf in covered:raise ValueError('Duplicate input mapping: '+leaf)
                covered[leaf]=value
    all_inputs=leaf_values(inp)
    # Metadata can contain identifiers and dates, never hidden numeric drivers.
    exempt={k:v for k,v in all_inputs.items() if k.startswith('/metadata/')}
    if any(isinstance(v,(int,float,bool)) for v in exempt.values()):raise ValueError('Numeric assumption hidden in metadata')
    expected={k:v for k,v in all_inputs.items() if k not in exempt}
    if covered!=expected:raise ValueError('Unreviewed or unknown input paths: '+str(sorted(set(expected)^set(covered))))
    mechanisms=json.loads(files['mechanisms'].read_text('utf-8'))
    for field in ['historical_reconstruction','forecast_transition','limitations']:
        if not mechanisms.get(field):raise ValueError('Operating reconstruction/transition missing: '+field)
    for field in ['revenue','construction_cost','operating_expenses','parent_eps','funding']:
        mechanism=mechanisms.get(field,{})
        if not mechanism.get('formula') or not mechanism.get('input_paths') or not mechanism.get('assumption_ids'):
            raise ValueError('Operating driver/cost build missing: '+field)
        if not set(mechanism['assumption_ids'])<={a['id'] for a in assumptions}:raise ValueError('Operating mechanism references unknown assumption')
        for path in mechanism['input_paths']:pointer(inp,path)
    outputs=json.loads(files['outputs'].read_text('utf-8'))
    bridges=json.loads(files['bridges'].read_text('utf-8'))
    if not {'bear','base','bull'}<=set(outputs.get('cases',{})):raise ValueError('Three annual operating cases required')
    for case,result in outputs['cases'].items():
        annual=result.get('annual',[])
        if len(annual)!=4:raise ValueError('Four comparable fiscal years required')
        paths=[r['period_end'] for r in annual]
        if len(set(paths))!=4:raise ValueError('Duplicate fiscal periods')
        for row in annual:
            for field in ['revenue','gross_profit','sga','ebit','recurring_parent_profit','recurring_eps','shares_m','cash','debt']:
                if not isinstance(row.get(field),(int,float)) or not math.isfinite(row[field]):raise ValueError('Incomplete/nonfinite annual P&L/funding')
            if abs(row['gross_profit']-row['sga']+row.get('reported_rounding',0)-row['ebit'])>1e-6:raise ValueError('OP bridge does not reconcile')
            if abs(row['recurring_parent_profit']/row['shares_m']-row['recurring_eps'])>1e-8:raise ValueError('EPS does not reconcile')
            for field in ['dividend_cash','principal','draw','debt']:
                if field in row and row[field]<-1e-8:raise ValueError('Negative cash distribution/financing amount: '+field)
    base=outputs['cases']['base']['annual'];annual_bridges=bridges.get('annual_changes',[])
    if len(annual_bridges)!=3:raise ValueError('Every annual earnings change needs a bridge')
    assumption_ids={a['id'] for a in assumptions}
    for old,new,bridge in zip(base,base[1:],annual_bridges):
        if bridge.get('from')!=old['period_end'] or bridge.get('to')!=new['period_end'] or not bridge.get('explanation'):
            raise ValueError('Missing annual direction-change explanation')
        for metric in ['ebit','recurring_eps']:
            components=bridge.get(metric,[])
            if not components or any(not x.get('label') or not x.get('assumption_ids') or not set(x['assumption_ids'])<=assumption_ids for x in components):
                raise ValueError('Profit bridge has no operating input lineage')
            if abs(sum(x['change'] for x in components)-(new[metric]-old[metric]))>1e-7:raise ValueError('Annual change bridge fails reconciliation')
    review=c.get('independent_review',{})
    if require_review:
        if review.get('status')!='approved' or not review.get('reviewer'):raise ValueError('Independent economic signoff required')
        rp=_resolved(root,review['archive'])
        if sha(rp)!=review.get('sha256'):raise ValueError('Economic signoff changed')
        r=json.loads(rp.read_text('utf-8'))
        if r.get('status')!='approved' or r.get('contract_digest')!=run_digest(c) or not r.get('economic_judgment'):
            raise ValueError('Economic signoff is not bound to this complete run')
        for field in ['operating_lineage','base_case_judgment','material_uncertainties','independence','independent_reconstruction']:
            if not r.get(field):raise ValueError('Independent economic review missing: '+field)
    if replay:
        sys.dont_write_bytecode=True
        spec=importlib.util.spec_from_file_location('_verified_forecast_'+sha(files['model'])[:12],files['model'])
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        for case,saved in outputs['cases'].items():
            actual=module.evaluate(copy.deepcopy(inp),case)
            if canonical_hash(actual)!=canonical_hash(saved):raise ValueError('Executable replay differs from sealed outputs: '+case)
    identity=canonical_hash({role:record['sha256'] for role,record in sorted(c['files'].items())})
    if c.get('run_id')!=identity:raise ValueError('Forecast run identity differs from artifact set')
    return dict(status='PASS_COMPLETE_FORECAST_RUN' if require_review else 'PASS_COMPLETE_RUN_PENDING_ECONOMIC_REVIEW',run_id=identity,assumptions=len(assumptions),input_paths=len(covered),sources=len(source_map),files={k:str(v) for k,v in files.items()})


def validate_promotion(record,model):
    """New model promotions cannot substitute labels/endpoint hashes for review."""
    path=record.get('economic_contract_path') or model.get('economic_contract_path')
    if not path:raise ValueError('New forecast promotion requires a complete economic contract')
    proof=validate_run(path,require_review=True,replay=True)
    if record.get('forecast_run_id')!=proof['run_id'] or model.get('forecast_run_id')!=proof['run_id']:
        raise ValueError('Promoted forecast is not the reviewed run')
    annual=json.loads(Path(proof['files']['outputs']).read_text('utf-8'))['cases']
    if canonical_hash(model.get('cases'))!=canonical_hash(annual):
        raise ValueError('Canonical operating/funding model differs from reviewed outputs')
    for case in ['bear','base','bull']:
        if record['annual_recurring_eps'][case]!=[r['recurring_eps'] for r in annual[case]['annual']]:
            raise ValueError('Promoted EPS path differs from reviewed run')
    return proof
