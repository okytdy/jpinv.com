Run python model/model.py to reproduce all cases.
Validate: from tools.forecast_evidence import validate_run; validate_run("model/ECONOMIC_CONTRACT.json", replay=True).
All amounts are JPY millions except EPS and million shares. Guidance is not an input.
