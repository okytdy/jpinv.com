# Independent economic approval — Dai-Dan reconciled v4

Reviewer: `/root/forecast_economic_reviewer` · 14 November 2026 JST.

**Approved for the exact run recorded in `ECONOMIC_REVIEW.json`.** The rebuilt central case is a defensible, explicitly conditional JII forecast. It replaces an unsupported annual margin schedule with a source-anchored operating model and exposes the assumptions that can make earnings rise or fall. Approval does not turn its financial proxies into disclosed project schedules or management forecasts.

## Economic judgment

Current H1 actuals remain fixed. The current H2 forecast applies the observed H1 revenue growth to prior H2 delivery and carries the observed like-half gross-profit improvement into the prior H2 recognition profile. The issuer attributes improvement to established execution changes and price recovery; it has not quantified a temporary component that would support a selected central haircut. Full carry is therefore defensible as the working central hypothesis. Half and zero carry remain important alternatives because large-project progress and completion affect recognized margins.

The central staffing proxy of 5.0307% equals the latest complete-year consolidated growth, 2,568/2,445−1. It fits continuing active hiring more naturally than a sharp unexplained slowdown. It remains a financial capacity/cost proxy, not a detailed employee forecast. The separate 1% productivity gain is a modest analyst estimate grounded qualitatively in employee maturation and execution changes. It is tested against zero. Capacity and labor cost respond coherently.

The 4% new-bid price and nonlabor-input paths use the issuer's construction-inflation planning reference as an anchor, not as proof of realized price increases. The 5% wage path is independently anchored in the disclosed cumulative 15.77% base-pay rise over three years; base pay is not total compensation. New bid prices and escalation factors attach to new award vintages. Opening nominal backlog receives no automatic price uplift. Parallel recognition is a bounded timing convention and avoids unsupported FIFO sequencing.

The H2 recognition-cost profile differs explicitly from the prospective full-year blended profile. Fixed bid values and incremental escalation factors do not establish immutable absolute project cost budgets. This distinction was repaired during review. Both construction and SG&A cash-cost measures are financial proxies; unseparated pension and accrual timing are handled approximately in funding.

The central model produces OP of ¥48.10bn, ¥50.89bn, ¥54.79bn and ¥59.41bn, and recurring EPS of ¥251.10, ¥273.85, ¥294.67 and ¥319.25. The 8.33% EPS CAGR is not an input or calibration target. Gross margin stays near 26.3%; OP margin declines from 17.52% to 17.04% because staff/pay and support costs grow faster than recognized sales. The model therefore retains justified cost pressure while removing the unsupported OP decline.

## Independent reconstruction

I wrote a separate reference-work ledger and funding calculation in the review directory. It rebuilds revenue, recognized construction costs, SG&A, depreciation, OP, parent EPS, working capital, cash, debt and timed dividends directly from the raw inputs. Its funding calculation iterates cash and dividends independently of the submitted engine's funding solver.

All bear/base/bull annual outcomes agree within ¥0.0000001m, or the corresponding per-share tolerance. All annual OP/EPS bridges and all 15 sealed sensitivity records reconstruct. The old-to-new reconciliation sums exactly and its sales-at-old-margin component independently recomputes. The submitted source, assumption, mechanism, output, sensitivity and reconciliation hashes are retained in the reconstruction record.

The principal independent sensitivities illustrate the economic stakes:

| Assumption | FY3/30 recurring EPS | EPS CAGR from its own FY0 |
|---|---:|---:|
| Base | ¥319.25 | 8.33% |
| Half improvement carry | ¥297.41 | 8.34% |
| No improvement carry | ¥275.57 | 8.34% |
| New bid prices grow 3%, other base assumptions retained | ¥291.04 | 5.04% |
| No productivity gain | ¥303.76 | 6.55% |
| Staffing proxy grows 3% | ¥300.83 | 6.21% |

Changing persistence also changes the starting earnings base, so CAGR alone conceals its effect. EPS levels and annual OP changes must accompany it. The FY3/28 EPS increase of ¥22.74 includes ¥8.24 from actual-H1 versus forward tax/minority normalization. It should not all be described as operating growth.

## Source and accounting checks

I visually checked corrected presentation pp24 and 31, the statutory H1 P&L p11, and annual construction-cost report p124. I independently checked the H1 and annual SG&A, depreciation, pension, tax, nonoperating and share disclosures. The November 12 correction is retained. The 8.02% consolidated workforce increase is March-to-September growth, not annual growth.

The disclosed parent construction employee-cost share is 28,292/175,478, or 16.12%. It includes design/management labor allocated to construction; applying it to consolidated escalation is an identified proxy. Current SG&A compensation mix is also a proxy for future annual mix.

EPS closing net shares of 129.543524m differ from legally dividend-eligible shares of 130.186304m because BIP trust shares receive dividends. The known interim cash payment uses the disclosed ¥5,467m aggregate. Prospective payments preserve record/payment timing. The authorization to repurchase shares receives no execution credit.

Forward tax uses the observed TTM effective rate of 31.011%, not an arbitrary midpoint or an assumed wage-credit expiration. H1 recurring normalization retains its own actual tax/minority basis. The cash-flow pension adjustment is an aggregate observed conversion proxy, not an inferred cash contribution.

## Repairs required and completed

Review challenged the workforce time base, unsupported TTM reset, staffing deceleration, absolute-project-budget language, full-year expense scope, pension cash inference and legal dividend shares. The author repaired these issues.

The no-awards loss stress exposed a negative dividend cash flow that incorrectly created cash and an unverified immediate tax refund. Both were repaired: payout-derived tranches cannot fall below zero, and loss periods receive no assumed tax refund or deferred-tax asset. CAGR is null when endpoints are nonpositive. Actual H1 remains unchanged under prospective pension stress.

A separate forced-draw reconstruction, with 120 extra collection days, 20% deposit unwind and a three-month liquidity floor, agrees with the engine. It requires a peak new draw of about ¥62.20bn and lowers future EPS through interest. The current positive base/bear/bull paths and moderate cash-delay stresses require no new funding. The final loss stress and low-cash stress reconstruct after the repairs.

## Material uncertainties retained

Full improvement persistence, project completion mix, price/cost pass-through, hiring and productivity remain the dominant operating uncertainties. Historical matching is not a seasonal law. The model lacks physical project schedules and consolidated labor detail; it honestly uses financial proxies.

The current-year JII forecast is above company guidance, materially because of H2 delivery and profitability persistence. Company guidance remains an external comparator; the evidence does not prove the JII outcome or establish that management guidance is deliberately conservative.

Cash is an approximate financing check. September bonus provisions, other current liabilities, cash-tax timing, investment classification, pension scope and other balance/OCI changes are not individually projected. Positive cash is not distributable surplus. The cash-inclusive capital/ROCE measure is a proxy, and future lease-accounting adoption is not estimated. No acquisition EPS or unexecuted buyback benefit is claimed.

## Core workflow assessment

The revised contract maps every numerical input leaf, retains source passages and correction review, requires an operating-mechanism/transition record, and binds code, assumptions, sources, outputs, bridges and review to one run. Publication replays that run and derives annual tables/downloads from it. New promotion cannot substitute an old schema or an annual CSV for approval. I independently ran the 12 regression tests; all passed.

Mechanical validation proves completeness, arithmetic and artifact identity. It cannot determine whether prose supplies a convincing economic reason. The signed reviewer fields and independent reconstruction are therefore essential: an annual sales-times-margin recipe dressed with files must still be rejected by the economic reviewer. This model has a genuine operating build and passes that substantive test. No unresolved material finding remains for the reviewed run.
