"""Independent reviewer calculations; not the production forecast engine.

Rebuild principal operating and EPS outcomes from raw inputs using a separate
reference-work ledger, then check cash, debt, and the saved annual bridges.
"""
import copy
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
M = ROOT / "model"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reconstruct(inp, case="base"):
    facts = inp["actual"]
    q = inp["cases"][case]
    h, old_h, old_y = (facts[k] for k in ("h1", "prior_h1", "prior_fy"))
    cost_ex_da = lambda r: r["sga"] - sum(r[k] for k in ("sga_da", "goodwill_amort", "pension_expense", "equity_pay"))
    ex_da_h2_sales = old_y["revenue"] - old_h["revenue"]
    current_h2_capacity = ex_da_h2_sales * h["revenue"] / old_h["revenue"] * q["h2_delivery_factor"]
    h1_direct_da = h["da"] - h["sga_da"]
    old_direct_da = old_h["da"] - old_h["sga_da"]
    old_h2_direct_da = old_y["da"] - old_y["sga_da"] - old_direct_da
    gain = (h["gross_profit"] + h1_direct_da) / h["revenue"] - (old_h["gross_profit"] + old_direct_da) / old_h["revenue"]
    h2_gp_rate = (old_y["gross_profit"] - old_h["gross_profit"] + old_h2_direct_da) / ex_da_h2_sales + gain * q["improvement_carry"]
    h2_overhead = (cost_ex_da(old_y) - cost_ex_da(old_h)) * cost_ex_da(h) / cost_ex_da(old_h)
    annual_capacity = h["revenue"] + current_h2_capacity
    initial_capacity = annual_capacity
    future_cost_ratio = (h["revenue"] - h["gross_profit"] - h1_direct_da + current_h2_capacity * (1-h2_gp_rate)) / annual_capacity
    staff_weight = h["cash_people_cost"] / cost_ex_da(h)
    overhead = cost_ex_da(h) + h2_overhead
    eligibility = ex_da_h2_sales / facts["prior_september_backlog"] * q["recognition_factor"]
    eligibility = min(1, eligibility)
    # Each item stores remaining work in current reference-price units.
    work = {lane: [[v["backlog"], 1., 1., True]] for lane, v in facts["lanes"].items()}
    lane_weights = {lane: v["h1_revenue"] / sum(z["h1_revenue"] for z in facts["lanes"].values()) for lane, v in facts["lanes"].items()}
    labor_fraction = facts["parent_direct_labor"] / facts["parent_construction_cost"]
    price, input_budget = 1., 1.
    full_da = 2*h["da"]
    ppe_anchor = 2*h["ppe_cash_spend"]
    historical_da_mix = h["sga_da"] / h["da"]
    capital_da = []
    op_rows = []
    for y in range(4):
        if y:
            real_growth = (1+q["headcount_growth"])*(1+q["productivity_growth"])
            annual_capacity *= real_growth
            overhead *= staff_weight*(1+q["headcount_growth"])*(1+q["pay_growth"]) + (1-staff_weight)*real_growth*(1+q["nonlabor_input_growth"])
            price *= 1+q["new_bid_price_growth"]
            input_budget *= (1-labor_fraction)*(1+q["nonlabor_input_growth"]) + labor_fraction*(1+q["pay_growth"])/(1+q["productivity_growth"])
        revenues, construction = 0., 0.
        capacity_used = 0.
        for half in range(1 if y == 0 else 2):
            half_capacity = current_h2_capacity if y == 0 else annual_capacity / 2
            for lane, anchor in facts["lanes"].items():
                eligible = [r[0] * eligibility for r in work[lane]]
                new_reference = anchor["ttm_orders"] * (1+q["orders_growth"])**(y+1) / (2*price)
                work[lane].append([new_reference, price, input_budget, False])
                eligible.append(new_reference*eligibility*inp["conventions"]["new_order_halfyear_exposure"])
                available = sum(eligible)
                fraction = min(1., half_capacity*lane_weights[lane]/available) if available else 0.
                for job, amount in zip(work[lane], eligible):
                    delivered = amount*fraction
                    job[0] -= delivered
                    revenues += delivered*job[1]
                    # Cost budget is held at award; divide future-cost factor by
                    # bid price only when converting reference to nominal costs.
                    cost_ratio = 1-h2_gp_rate if y == 0 else future_cost_ratio
                    construction += delivered*job[2]*cost_ratio*(1+q["legacy_overrun"] if job[3] else 1.)
                    capacity_used += delivered
        if y == 0:
            gross = h["gross_profit"] + revenues - construction - h1_direct_da
            revenues += h["revenue"]
            total_da = full_da
        else:
            total_da = full_da + sum(capital_da)
            gross = revenues - construction - total_da*(1-historical_da_mix)
        ppe = ppe_anchor*annual_capacity/initial_capacity
        expansion_da = max(0., ppe-full_da)/q["asset_life"]
        initial_depreciation = expansion_da*(.25 if y == 0 else .5)
        capital_da.append(expansion_da)
        total_da += initial_depreciation
        gross -= initial_depreciation*(1-historical_da_mix)
        pension = h["pension_expense"]*(1+q["pension_credit_carry"]) if y == 0 else 2*h["pension_expense"]*q["pension_credit_carry"]
        selling = overhead + total_da*historical_da_mix + 2*(h["goodwill_amort"]+h["equity_pay"]) + pension
        rounded = h["ebit"]-h["gross_profit"]+h["sga"] if y == 0 else 0.
        op_rows.append(dict(revenue=revenues, gross_profit=gross, sga=selling, ebit=gross-selling+rounded,
                            da=total_da, cash_sga=overhead, cash_ppe=ppe*(.5 if y == 0 else 1.),
                            backlog=sum(job[0]*job[1] for lane in work.values() for job in lane),
                            capacity=annual_capacity, used=capacity_used))
    # Independent funding and EPS reconstruction. Iterate draw/dividend interest
    # rather than using the engine's closed-form draw equation.
    cash, debt = facts["cash"], facts["debt"]
    wc = facts["receivables"]+facts["inventory"]-facts["payables"]-facts["advances"]
    deposits = facts["other_deposits"]
    original_book = sum(v["backlog"] for v in facts["lanes"].values())
    h1_core = h["parent_profit"]-h["extraordinary_net"]*(1-h["tax"]/h["pbt"])*(1-h["nci"]/h["group_profit"])
    for y, row in enumerate(op_rows):
        duration = .5 if y == 0 else 1.
        shares = (facts["h1_weighted_shares_m"]+facts["closing_eps_shares_m"])/2 if y == 0 else facts["closing_eps_shares_m"]
        op_forward = row["ebit"]-h["ebit"] if y == 0 else row["ebit"]
        nonop_forward = facts["ttm_recurring_nonop_before_interest"]*duration
        next_wc = row["revenue"]*(facts["receivables"]+facts["inventory"])/(2*h["revenue"]) + row["revenue"]*q["collection_delay_days"]/365 - (row["revenue"]-row["gross_profit"])*facts["payables"]/(2*(h["revenue"]-h["gross_profit"])) - row["backlog"]*facts["advances"]/original_book
        deposit_use = deposits*q["other_deposit_unwind"]*duration
        deposits -= deposit_use
        noncash = row["da"]-(h["da"] if y == 0 else 0.) + 2*duration*(h["goodwill_amort"]+h["equity_pay"]+h["pension_cf_adjustment"]+h["pension_expense"]*(q["pension_credit_carry"]-1))
        principal = min(debt, facts["annual_principal_runrate"]*duration)
        draw = 0.
        for iteration in range(50):
            interest = debt*q["debt_interest_rate"]*duration + draw*q["debt_interest_rate"]*duration/2
            pretax = op_forward+nonop_forward-interest
            group = pretax-max(0., pretax*q["tax_rate"])
            parent = group*(1-q["nci_claim_rate"])+(h1_core if y == 0 else 0.)
            if y == 0:
                dividend = facts["declared_interim_cash"]
            else:
                previous_final = facts["announced_final_dps"]*facts["dividend_eligible_shares_m"] if y == 1 else max(0., op_rows[y-1]["parent"])*q["payout"]*.5*facts["dividend_eligible_shares_m"]/op_rows[y-1]["shares"]
                dividend = previous_final+max(0., parent)*q["payout"]*.5*facts["dividend_eligible_shares_m"]/shares
            cf = group+noncash-(next_wc-wc)-deposit_use
            before = cash+cf-row["cash_ppe"]-2*h["other_investing_outflow"]*duration-dividend-principal
            needed = max(0., row["revenue"]*q["liquidity_months"]/12-before)
            if abs(needed-draw) < 1e-10:
                break
            draw = needed
        cash = before+draw
        debt = debt-principal+draw
        row.update(parent=parent, shares=shares, recurring_eps=parent/shares, cash=cash, debt=debt, draw=draw, cashflow=cf, dividend_cash=dividend, working_capital=next_wc)
        wc = next_wc
    return op_rows


def main():
    inp = json.loads((M/"INPUTS.json").read_text("utf-8"))
    saved = json.loads((M/"OUTPUTS.json").read_text("utf-8"))
    comparisons = {}
    for case in ("bear", "base", "bull"):
        reconstructed = reconstruct(inp, case)
        discrepancies = []
        for own, approved in zip(reconstructed, saved["cases"][case]["annual"]):
            for metric in ("revenue", "gross_profit", "sga", "ebit", "recurring_eps", "cash", "debt", "cashflow", "dividend_cash", "working_capital"):
                if abs(own[metric]-approved[metric]) > 1e-7:
                    discrepancies.append([approved["period_end"], metric, own[metric], approved[metric]])
        comparisons[case] = dict(discrepancies=discrepancies, annual=reconstructed)
    sensitivity = {}
    variations = {"no_improvement_carry": {"improvement_carry": 0.}, "half_carry": {"improvement_carry": .5}, "staff_3pct": {"headcount_growth": .03}, "staff_8pct": {"headcount_growth": .08}, "no_productivity": {"productivity_growth": 0.}, "bid_minus1pp": {"new_bid_price_growth": .03}, "input_plus1pp": {"nonlabor_input_growth": .05}, "pay_plus1pp": {"pay_growth": .06}, "legacy_cost_plus1pct": {"legacy_overrun": .01}, "no_pension_credit": {"pension_credit_carry": 0.}, "funding_delay30": {"collection_delay_days": 30., "other_deposit_unwind": .2}, "funding_forced_draw": {"collection_delay_days": 120., "other_deposit_unwind": .2, "liquidity_months": 3.}}
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("submitted_engine_for_perturbation_comparison", M/"model.py")
    submitted = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(submitted)
    stress_errors = []
    for name, changed in variations.items():
        altered = copy.deepcopy(inp)
        altered["cases"]["base"].update(changed)
        rows = reconstruct(altered)
        engine_rows = submitted.evaluate(copy.deepcopy(altered))["annual"]
        for own, production in zip(rows, engine_rows):
            for metric in ("revenue", "gross_profit", "sga", "ebit", "recurring_eps", "cash", "debt", "cashflow", "dividend_cash", "working_capital"):
                if abs(own[metric]-production[metric]) > 1e-7:
                    stress_errors.append([name, production["period_end"], metric, own[metric], production[metric]])
        sensitivity[name] = {"changes": changed, "fy0_eps": rows[0]["recurring_eps"], "fy1_eps": rows[1]["recurring_eps"], "fy3_eps": rows[-1]["recurring_eps"], "fy3_op": rows[-1]["ebit"], "eps_cagr": (rows[-1]["recurring_eps"]/rows[0]["recurring_eps"])**(1/3)-1, "min_cash": min(r["cash"] for r in rows), "max_draw": max(r["draw"] for r in rows)}
    # Output bridges must sum at full precision, independent of prose labels.
    bridges = json.loads((M/"BRIDGES.json").read_text("utf-8"))["annual_changes"]
    bridge_errors = []
    for i, bridge in enumerate(bridges):
        old, new = comparisons["base"]["annual"][i:i+2]
        for metric in ("ebit", "recurring_eps"):
            error = sum(c["change"] for c in bridge[metric])-(new[metric]-old[metric])
            if abs(error) > 1e-7:
                bridge_errors.append([i, metric, error])
    artifact_errors = []
    sensitivities = json.loads((M/"SENSITIVITIES.json").read_text("utf-8"))
    for item in sensitivities["sensitivities"]:
        altered = copy.deepcopy(inp)
        for key, value in item["changes"].items():
            if key == "__new_exposure":
                altered["conventions"]["new_order_halfyear_exposure"] = value
            elif key == "__cash":
                altered["actual"]["cash"] = value
            else:
                altered["cases"]["base"][key] = value
        own = reconstruct(altered)
        cagr = (own[-1]["recurring_eps"]/own[0]["recurring_eps"])**(1/3)-1 if min(own[-1]["recurring_eps"], own[0]["recurring_eps"]) > 0 else None
        calculated = dict(fy0_eps=own[0]["recurring_eps"], fy3_eps=own[-1]["recurring_eps"], eps_cagr=cagr, fy1_op=own[1]["ebit"], fy1_op_change=own[1]["ebit"]-own[0]["ebit"], fy3_ebit=own[-1]["ebit"], fy3_cash=own[-1]["cash"], peak_debt=max(x["debt"] for x in own))
        for key, value in calculated.items():
            expected = item[key]
            if (value is None) != (expected is None) or (value is not None and abs(value-expected) > 1e-7):
                artifact_errors.append([item["label"], key, value, expected])
    reconciliation = json.loads((M/"RECONCILIATION.json").read_text("utf-8"))
    for item in reconciliation["annual_comparisons"]:
        for metric, ending in (("ebit", "ebit"), ("eps", "eps")):
            error = sum(x["change"] for x in item[metric+"_bridge"])-(item["new_"+ending]-item["old_"+ending])
            if abs(error) > 1e-7:
                artifact_errors.append([item["source"], item["period_end"], metric, error])
        expected_sales_change = (item["new_revenue"]-item["old_revenue"])*item["old_ebit"]/item["old_revenue"]
        if abs(expected_sales_change-item["ebit_bridge"][0]["change"]) > 1e-7:
            artifact_errors.append([item["source"], item["period_end"], "sales reconciliation"])
    contract = json.loads((M/"ECONOMIC_CONTRACT.json").read_text("utf-8"))
    result = {"hashes": {record["path"]: digest(M/record["path"]) for record in contract["files"].values()}, "forecast_run_id": contract["run_id"], "comparisons": comparisons, "sensitivities": sensitivity, "bridge_errors": bridge_errors, "stress_errors": stress_errors, "artifact_errors": artifact_errors}
    (ROOT/"reviews"/"INDEPENDENT_RECONSTRUCTION.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"forecast_run_id": contract["run_id"], "discrepancies": {k: v["discrepancies"] for k, v in comparisons.items()}, "bridge_errors": bridge_errors, "stress_errors": stress_errors, "artifact_errors": artifact_errors, "sensitivities": sensitivity}, indent=2))


if __name__ == "__main__":
    main()
