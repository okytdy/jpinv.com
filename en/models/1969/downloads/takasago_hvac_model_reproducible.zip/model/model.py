"""Takasago: backlog/delivery proxy, observed cost budgets and parent funding.

All JPY millions except million shares and EPS yen. Financial work/capacity
proxies are not physical units. Guidance is a separate comparator only.
"""

def evaluate(inputs,case='base'):
    a=inputs['actual'];p=inputs['cases'][case];c=inputs['conventions']
    backlog=a['backlog'];cash=a['cash'];debt=a['debt']
    ar=a['receivables'];inventory=a['inventory'];ap=a['payables'];advance=a['advances']
    tax_payable=a['tax_payable'];bonus_payable=a['bonus_payable']
    prior_rev=None;prior_parent=None;first_parent=None;previous_final=a['announced_final_cash'];rows=[];new_assets=[]
    seasonality=p['h2_sga_seasonality']
    cash_cogs_ratio=(a['h1_revenue']-a['h1_gross_profit']-a['h1_core_da'])/a['h1_revenue']
    tax_rate=p['tax_rate'];yearend_ar=a['march_receivables']/a['prior_fy_revenue']
    yearend_ap=a['march_payables']/(a['prior_fy_revenue']-a['prior_fy_gross_profit'])
    yearend_inventory=a['march_inventory']/(a['prior_fy_revenue']-a['prior_fy_gross_profit'])
    yearend_advance=a['march_advances']/a['prior_fy_revenue']
    normalized_h1_parent=a['h1_parent_profit']+a['h1_impairment']*(1-p['impairment_tax_benefit_rate'])-a['h1_share_sale_gain']*(1-p['share_sale_tax_rate'])
    recognition=(a['prior_fy_revenue']-a['prior_h1_revenue'])/(a['prior_september_backlog']+a['prior_fy_orders']-a['prior_h1_orders'])
    for i,year in enumerate(c['years']):
        actual=i==0;duration=c['first_fraction'] if actual else 1
        orders=a['ttm_orders']*(1+p['order_growth'])**(i+duration)*duration
        available=backlog+orders
        demand_delivery=available*recognition*p['recognition_multiplier'] if actual else available*p['annual_pool_conversion']
        if actual:
            revenue=demand_delivery
        else:
            throughput=prior_rev*(1+p['real_throughput_growth'])*(1+p['effective_new_mix_price'])
            revenue=min(demand_delivery,throughput)
        if revenue<0 or revenue>available:raise ValueError('Delivery exceeds available work')
        ending_backlog=available-revenue
        full_revenue=revenue+(a['h1_revenue'] if actual else 0)
        if actual:
            personnel=a['h1_sga_personnel']*seasonality
            other_sga=(a['h1_sga']-a['h1_sga_personnel']-a['h1_goodwill_amort'])*seasonality
            direct_cash=revenue*cash_cogs_ratio*p['current_cost_factor']
        else:
            personnel=rows[-1]['personnel']*(1+p['pay_growth'])*(1+p['staff_growth'])
            other_sga=rows[-1]['other_sga']*(1+p['other_cost_inflation'])*(1+p['other_scope_growth'])
            # Aggregate portfolio budget proxy: delivered activity, effective
            # new-contract mix and input/productivity response, not old-bid repricing.
            direct_cash=rows[-1]['direct_cash_cost']*(revenue/prior_rev)/(1+p['effective_new_mix_price'])*(1+p['net_direct_cost_growth'])
        capex=p['annual_capex']*(1+p['capex_growth'])**i*duration
        new_assets.append((i,capex))
        da=a['h1_core_da']/a['actual_fraction']*duration+sum(spend/p['asset_life']*(duration/2 if start==i else duration) for start,spend in new_assets)
        goodwill=a['h1_goodwill_amort']/a['actual_fraction']*duration
        future_gp=revenue-direct_cash-da
        op=future_gp-personnel-other_sga-goodwill
        recurring_other=(a['h1_nonop_ex_interest_dividends']/a['actual_fraction']+a['h1_dividends']/a['actual_fraction']*p['portfolio_dividend_retained'])*duration
        nci=a['h1_nci']/a['actual_fraction']*(1+p['nci_growth'])**i*duration
        repay=min(debt,a['current_debt']) if actual else min(debt,p['annual_principal'])
        end_ar=full_revenue*yearend_ar;end_inventory=(full_revenue-(future_gp+(a['h1_gross_profit'] if actual else 0)))*yearend_inventory
        end_ap=(full_revenue-(future_gp+(a['h1_gross_profit'] if actual else 0)))*yearend_ap
        end_advance=full_revenue*yearend_advance
        wc=end_ar-ar+end_inventory-inventory-(end_ap-ap)-(end_advance-advance)
        full_sga=personnel+other_sga+goodwill+(a['h1_sga'] if actual else 0)
        desired_bonus=full_sga*p['bonus_sga_ratio']
        draw=0
        for _ in range(c['funding_iterations']):
            interest=(debt-repay/2)*p['debt_rate']*duration+draw*p['debt_rate']*duration/2
            cash_interest=cash*p['cash_yield']*duration
            pbt=op+recurring_other+cash_interest-interest
            tax=max(0,pbt)*tax_rate;parent=pbt-tax-nci
            if actual:
                annual_dps=a['announced_annual_dps'];dividend=a['announced_interim_cash']
            else:
                annual_dps=a['announced_annual_dps']*(max(0,parent)/first_parent)**p['dividend_profit_elasticity'] if first_parent>0 else 0
                dividend=previous_final+annual_dps/2*a['legal_dividend_shares']
            annual_tax=tax+(a['h1_reported_tax'] if actual else 0)
            desired_tax=annual_tax*p['tax_payable_ratio']
            cash_tax=max(0,tax+tax_payable-desired_tax)
            end_tax=tax_payable+tax-cash_tax
            cfo=parent+nci+da+goodwill+(tax-cash_tax)+(desired_bonus-bonus_payable)-wc
            before=cash+cfo-capex-dividend-p['lease_principal']*duration-repay
            need=max(0,p['minimum_cash']-before)
            if abs(need-draw)<c['funding_tolerance']:break
            draw=need
        full_gp=future_gp+(a['h1_gross_profit'] if actual else 0)
        full_op=full_gp-full_sga
        full_parent=parent+(normalized_h1_parent if actual else 0)
        shares=a['h1_weighted_shares']*a['actual_fraction']+a['closing_shares']*duration if actual else a['closing_shares']
        full_da=da+(a['h1_core_da'] if actual else 0)
        row=dict(period_end=f'{year}-03-31',revenue=full_revenue,gross_profit=full_gp,sga=full_sga,ebit=full_op,
                 op_margin=full_op/full_revenue,recurring_parent_profit=full_parent,shares_m=shares,recurring_eps=full_parent/shares,
                 cash=before+draw,debt=debt-repay+draw,backlog=ending_backlog,period_orders=orders,period_deliveries=revenue,
                 opening_backlog=backlog,backlog_error=ending_backlog-(backlog+orders-revenue),
                 direct_cash_cost=direct_cash+(a['h1_revenue']-a['h1_gross_profit']-a['h1_core_da'] if actual else 0),
                 personnel=personnel+(a['h1_sga_personnel'] if actual else 0),other_sga=other_sga+(a['h1_sga']-a['h1_sga_personnel']-a['h1_goodwill_amort'] if actual else 0),
                 da=full_da,goodwill_amort=goodwill+(a['h1_goodwill_amort'] if actual else 0),forward_period_fraction=duration,forward_interest=interest,forward_tax=tax,forward_nci=nci,
                 cash_tax=cash_tax,closing_tax_payable=end_tax,opening_tax_payable=tax_payable,closing_bonus_payable=desired_bonus,opening_bonus_payable=bonus_payable,
                 annual_dps=annual_dps,legal_dividend_shares_m=a['legal_dividend_shares'],dividend_cash_basis='Gross parent distributions; intercompany eliminations not quantified',
                 cfo=cfo+(a['h1_cfo'] if actual else 0),cash_capex=capex+(a['h1_cash_capex'] if actual else 0),
                 forward_cfo=cfo,forward_capex=capex,dividend_cash=dividend,principal=repay,draw=draw,
                 recognized_h1_aftertax_normalization=(normalized_h1_parent-a['h1_parent_profit'] if actual else 0),
                 segment_external_sales={name:full_revenue*value/a['h1_revenue'] for name,value in a['segment_sales'].items()},
                 forecast_cash_period='H2 only' if actual else 'full year')
        assert abs(full_gp-full_sga-full_op)<1e-7
        rows.append(row);backlog=ending_backlog;cash=row['cash'];debt=row['debt'];prior_rev=full_revenue;prior_parent=full_parent
        ar=end_ar;inventory=end_inventory;ap=end_ap;advance=end_advance
        tax_payable=end_tax;bonus_payable=desired_bonus
        if actual:first_parent=full_parent
        else:previous_final=annual_dps/2*a['legal_dividend_shares']
    return dict(annual=rows,eps_cagr=(rows[-1]['recurring_eps']/rows[0]['recurring_eps'])**(1/3)-1 if rows[0]['recurring_eps']>0 and rows[-1]['recurring_eps']>0 else None)
