"""Independent reviewer-owned Takasago reconstruction, not production authoring."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[1]


def own_forecast(x,case='base'):
    a=x['actual'];p=x['cases'][case];c=x['conventions']
    cash,debt,backlog=a['cash'],a['debt'],a['backlog']
    tax_liability,bonus_liability=a['tax_payable'],a['bonus_payable']
    balances=[a['receivables'],a['inventory'],a['payables'],a['advances']]
    h2_ratio=p['h2_sga_seasonality']
    recognition=(a['prior_fy_revenue']-a['prior_h1_revenue'])/(a['prior_september_backlog']+a['prior_fy_orders']-a['prior_h1_orders'])
    cash_cost=(a['h1_revenue']-a['h1_gross_profit']-a['h1_core_da'])/a['h1_revenue']
    yearend_ratios=[a['march_receivables']/a['prior_fy_revenue'],a['march_inventory']/(a['prior_fy_revenue']-a['prior_fy_gross_profit']),a['march_payables']/(a['prior_fy_revenue']-a['prior_fy_gross_profit']),a['march_advances']/a['prior_fy_revenue']]
    normalized_h1=a['h1_parent_profit']+a['h1_impairment']*(1-p['impairment_tax_benefit_rate'])-a['h1_share_sale_gain']*(1-p['share_sale_tax_rate'])
    rows=[];capital=[]
    prior_final=a['announced_final_cash'];first_parent=None
    for i,year in enumerate(c['years']):
        period=c['first_fraction'] if i==0 else 1.
        orders=a['ttm_orders']*(1+p['order_growth'])**(i+period)*period
        pool=backlog+orders
        if i==0:
            sales=pool*recognition*p['recognition_multiplier']
            staff=a['h1_sga_personnel']*h2_ratio
            overhead=(a['h1_sga']-a['h1_sga_personnel']-a['h1_goodwill_amort'])*h2_ratio
            direct=sales*cash_cost*p['current_cost_factor']
        else:
            sales=min(pool*p['annual_pool_conversion'],rows[-1]['revenue']*(1+p['real_throughput_growth'])*(1+p['effective_new_mix_price']))
            staff=rows[-1]['personnel']*(1+p['pay_growth'])*(1+p['staff_growth'])
            overhead=rows[-1]['other_sga']*(1+p['other_cost_inflation'])*(1+p['other_scope_growth'])
            direct=rows[-1]['direct_cash_cost']*sales/rows[-1]['revenue']*(1+p['net_direct_cost_growth'])/(1+p['effective_new_mix_price'])
        capex=p['annual_capex']*(1+p['capex_growth'])**i*period
        capital.append(capex)
        depreciation=a['h1_core_da']/a['actual_fraction']*period+sum(v/p['asset_life']*period*(.5 if j==i else 1.) for j,v in enumerate(capital))
        goodwill=a['h1_goodwill_amort']/a['actual_fraction']*period
        gross=sales-direct-depreciation
        operating=gross-staff-overhead-goodwill
        other=(a['h1_nonop_ex_interest_dividends']+a['h1_dividends']*p['portfolio_dividend_retained'])/a['actual_fraction']*period
        outsider=a['h1_nci']/a['actual_fraction']*(1+p['nci_growth'])**i*period
        principal=min(debt,a['current_debt'] if i==0 else p['annual_principal'])
        full_sales=sales+(a['h1_revenue'] if i==0 else 0.)
        full_gross=gross+(a['h1_gross_profit'] if i==0 else 0.)
        next_balances=[full_sales*yearend_ratios[0],(full_sales-full_gross)*yearend_ratios[1],(full_sales-full_gross)*yearend_ratios[2],full_sales*yearend_ratios[3]]
        working=sum((new-old)*sign for new,old,sign in zip(next_balances,balances,[1,1,-1,-1]))
        annual_sga=staff+overhead+goodwill+(a['h1_sga'] if i==0 else 0.)
        closing_bonus=annual_sga*p['bonus_sga_ratio']
        base_interest=(debt-principal/2)*p['debt_rate']*period
        cash_interest=cash*p['cash_yield']*period
        def settle(draw):
            interest=base_interest+draw*p['debt_rate']*period/2
            pretax=operating+other+cash_interest-interest
            tax=max(0.,pretax)*p['tax_rate']
            parent=pretax-tax-outsider
            annual_dps=a['announced_annual_dps'] if i==0 else a['announced_annual_dps']*(max(0.,parent)/first_parent)**p['dividend_profit_elasticity'] if first_parent>0 else 0.
            dividend=a['announced_interim_cash'] if i==0 else prior_final+annual_dps/2*a['legal_dividend_shares']
            annual_tax=tax+(a['h1_reported_tax'] if i==0 else 0.)
            cash_tax=max(0.,tax+tax_liability-annual_tax*p['tax_payable_ratio'])
            closing_tax=tax_liability+tax-cash_tax
            cfo=pretax-cash_tax+depreciation+goodwill+closing_bonus-bonus_liability-working
            ending_cash=cash+cfo-capex-dividend-p['lease_principal']*period-principal+draw
            return ending_cash,parent,cfo,interest,tax,cash_tax,closing_tax,annual_dps,dividend
        lo=0.;hi=max(1.,p['minimum_cash']-settle(0.)[0])
        if settle(0.)[0]>=p['minimum_cash']:draw=0.
        else:
            while settle(hi)[0]<p['minimum_cash']:hi*=2
            for _ in range(100):
                mid=(lo+hi)/2
                if settle(mid)[0]<p['minimum_cash']:lo=mid
                else:hi=mid
            draw=hi
        cash,parent,cfo,interest,tax,cash_tax,closing_tax,annual_dps,dividend=settle(draw)
        full_parent=parent+(normalized_h1 if i==0 else 0.)
        shares=(a['h1_weighted_shares']*a['actual_fraction']+a['closing_shares']*period) if i==0 else a['closing_shares']
        debt=debt-principal+draw;backlog=pool-sales
        row=dict(period_end=f'{year}-03-31',revenue=full_sales,gross_profit=full_gross,sga=annual_sga,ebit=operating+(a['h1_gross_profit']-a['h1_sga'] if i==0 else 0.),recurring_parent_profit=full_parent,recurring_eps=full_parent/shares,cash=cash,debt=debt,backlog=backlog,direct_cash_cost=direct+(a['h1_revenue']-a['h1_gross_profit']-a['h1_core_da'] if i==0 else 0.),personnel=staff+(a['h1_sga_personnel'] if i==0 else 0.),other_sga=overhead+(a['h1_sga']-a['h1_sga_personnel']-a['h1_goodwill_amort'] if i==0 else 0.),da=depreciation+(a['h1_core_da'] if i==0 else 0.),goodwill_amort=goodwill+(a['h1_goodwill_amort'] if i==0 else 0.),forward_cfo=cfo,forward_interest=interest,forward_tax=tax,cash_tax=cash_tax,closing_tax_payable=closing_tax,closing_bonus_payable=closing_bonus,draw=draw,annual_dps=annual_dps,dividend_cash=dividend)
        rows.append(row);balances=next_balances;tax_liability=closing_tax;bonus_liability=closing_bonus
        if i==0:first_parent=full_parent
        else:prior_final=annual_dps/2*a['legal_dividend_shares']
    return rows


def main():
    x=json.loads((R/'model/INPUTS.json').read_text('utf8'))
    spec=importlib.util.spec_from_file_location('submitted_takasago',R/'model/model.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    cases={};errors=[]
    for case in x['cases']:
        own=own_forecast(x,case);actual=m.evaluate(copy.deepcopy(x),case)['annual']
        for left,right in zip(own,actual):
            for key in left:
                if key=='period_end':continue
                if abs(left[key]-right[key])>1e-7:errors.append([case,left['period_end'],key,left[key],right[key]])
        cases[case]=own
    h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    sealed=json.loads((R/'model/SENSITIVITIES.json').read_text('utf8'))['sensitivities'];sensitivities={}
    for sensitivity in sealed:
        amended=copy.deepcopy(x)
        for path,value in sensitivity['input_changes'].items():
            node=amended;parts=path.strip('/').split('/')
            for part in parts[:-1]:node=node[part]
            node[parts[-1]]=value
        own=own_forecast(amended);candidate=m.evaluate(copy.deepcopy(amended),'base')['annual']
        for left,right in zip(own,candidate):
            for key in left:
                if key=='period_end':continue
                if abs(left[key]-right[key])>1e-7:errors.append(['sensitivity',sensitivity['label'],left['period_end'],key,left[key],right[key]])
        for key,value in {'fy0_eps':own[0]['recurring_eps'],'fy3_eps':own[-1]['recurring_eps'],'target_cash':own[-1]['cash'],'target_debt':own[-1]['debt']}.items():
            if abs(value-sensitivity[key])>1e-7:errors.append(['sealed_sensitivity',sensitivity['label'],key,value,sensitivity[key]])
        sensitivities[sensitivity['label']]=own
    result=dict(stage='FINAL_INDEPENDENT_RECONSTRUCTION',errors=errors,hashes={n:h(R/'model'/n) for n in ['model.py','INPUTS.json','DRIVER_NOTES.json']},comparisons=cases,sensitivities=sensitivities,source_calculations={'prior_h2_recognition':(423923-194501)/(399112+460057-218173),'prior_h2_to_h1_sga':(45974-19717)/19717,'matched_TTM_tax_rate':(14814+6203-6978)/(52826+17956-27302),'current_salary_plus_bonus_growth':(5575+2137)/(4940+2268)-1})
    extra={}
    for name,change in {'no_future_awards':{'order_growth':-1.},'asset_life_5':{'asset_life':5.},'asset_life_15':{'asset_life':15.},'cash_reserve_30bn':{'minimum_cash':30000.}}.items():
        amended=copy.deepcopy(x);amended['cases']['base'].update(change)
        own=own_forecast(amended);candidate=m.evaluate(copy.deepcopy(amended))['annual']
        for left,right in zip(own,candidate):
            for key in left:
                if key!='period_end' and abs(left[key]-right[key])>1e-7:errors.append(['extra',name,left['period_end'],key,left[key],right[key]])
        extra[name]=own
    bridges=json.loads((R/'model/BRIDGES.json').read_text('utf8'))['annual_changes']
    for i,bridge in enumerate(bridges):
        for key in ['ebit','recurring_eps']:
            error=sum(item['change'] for item in bridge[key])-(cases['base'][i+1][key]-cases['base'][i][key])
            if abs(error)>1e-7:errors.append(['bridge',bridge['to'],key,error])
    result['extra_review_sensitivities']=extra
    result['annual_bridge_check']='PASS' if not errors else 'FAIL'
    (R/'reviews/INDEPENDENT_RECONSTRUCTION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'errors':errors,'base':cases['base'],'source_calculations':result['source_calculations']},indent=2))


if __name__=='__main__':main()
